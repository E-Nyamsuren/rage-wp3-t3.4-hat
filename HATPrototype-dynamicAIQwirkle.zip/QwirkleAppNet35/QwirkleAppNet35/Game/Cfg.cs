﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Game
Filename: Cfg.cs
Description:
    Contains configurational settings as constants, static variables and static utility methods for the Qwirkle game.
Disclaimer:
    Qwirkle is an intelectual property of and trademarked by MindWare, Inc (http://www.mindware.com/).
    The author of this source code does not claim intelectual property rights to Qwirkle.
    The game is used for non-comercial education purpose only.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // [SC] For using Image class.
using System.Windows.Media.Imaging; // BitmapImage

namespace QwirkleAppNet35.Game 
{
    public static class Cfg
    {
        public const string GAME_ID = "Qwirkle"; 

        private static Random rng = new Random();

        public const int SIDE_PANEL_WIDTH = 300;
        public const int SIDE_PANEL_BTM_MARGIN = 10;
        public const int SIDE_ELEM_BTM_MARGIN = 5;

        public const int TILE_SIZE = 40;
        public const int CTRL_BTN_WIDTH = 150;
        public const int CTRL_BTN_HEIGHT = 50;

        public const int BOARD_COL_COUNT = 15;
        public const int BOARD_ROW_COUNT = 15;

        public const int LOC_BOARD = 0;
        public const int LOC_PLAYER = 1;
        public const int LOC_BAG = 2;

        public const int NONE = -1;

        public const int COLOR_ATTR = 1;
        public const int SHAPE_ATTR = 2;

        public const int MAX_VAL_INDEX = 6; // [SC] the the numeric id for color and shape features ranges from 0 to 5

        public const int MAX_TILE_ID = 3; // [SC] there can be three tiles of the same color:shape combination

        public const int MAX_BAG_SIZE = MAX_VAL_INDEX * MAX_VAL_INDEX * MAX_TILE_ID;

        public const int MAX_PLAYER_TILE_COUNT = 6;

        public const int START_TILE_COUNT = 3;

        public const string PLACE_BTN_NAME = "placeTile";
        public const string DROP_BTN_NAME = "dropTile";
        public const string TURN_BTN_NAME = "endTurn";
        public const string NEW_BTN_NAME = "newGame";
        public const string BTN_FILE_SUFFIX = ".jpg";

        public const string TILE_IMAGE_SUFFIX = "_15_50.jpg";
        //public const string RESOURCE_URI = "/QwirkleApp.Game;component/resources/";
        public const string RESOURCE_URI = "pack://application:,,,/resources/";

        public const int HORIZONTAL = 1;
        public const int VERTICAL = 2;


        public const long ACTION_DELAY = 2000;
        public const long TURN_DURATION = 10000;


        public const int LAST_PLAYER_REWARD = 6;
        public const int MAX_SEQ_SCORE = 6;
        public const int QWIRKLE_REWARD = MAX_SEQ_SCORE * 2;


        public const string HUMAN_PLAYER = "Human";
        public const string VERY_EASY_AI = "Very Easy AI";
        public const string EASY_AI = "Easy AI";
        public const string MEDIUM_COLOR_AI = "Medium Color AI";
        public const string MEDIUM_SHAPE_AI = "Medium Shape AI";
        public const string HARD_AI = "Hard AI";
        public const string VERY_HARD_AI = "Very Hard AI";

        private static BitmapImage[,] tileBitmapImageArray = loadTileImages();

        private static BitmapImage[,] loadTileImages() {
            BitmapImage[,] tileBitmapImageArray = new BitmapImage[MAX_VAL_INDEX, MAX_VAL_INDEX];

            for (int colorIndex = 0; colorIndex < MAX_VAL_INDEX; colorIndex++) {
                for (int shapeIndex = 0; shapeIndex < MAX_VAL_INDEX; shapeIndex++) {
                    tileBitmapImageArray[colorIndex, shapeIndex] = loadTileBitmapImage(colorIndex, shapeIndex);
                }
            }

            return tileBitmapImageArray;
        }

        public static BitmapImage loadTileBitmapImage(int colorIndex, int shapeIndex) {
            return loadBitmapImage(getTileFeatureID(colorIndex, shapeIndex) + TILE_IMAGE_SUFFIX);
        }

        public static Image getTileImage(int colorIndex, int shapeIndex) {
            return createImage(tileBitmapImageArray[colorIndex, shapeIndex]);
        }

        public static string getTileFeatureID(int colorIndex, int shapeIndex) {
            return colorIndex + "" + shapeIndex;
        }

        public static Image loadPlaceBtnImage() {
            return createImage(loadBitmapImage(PLACE_BTN_NAME + BTN_FILE_SUFFIX));
        }

        public static Image loadDropBtnImage() {
            return createImage(loadBitmapImage(DROP_BTN_NAME + BTN_FILE_SUFFIX));
        }

        public static Image loadEndTurnBtnImage() {
            return createImage(loadBitmapImage(TURN_BTN_NAME + BTN_FILE_SUFFIX));
        }

        public static Image loadNewGameBtnImage() {
            return createImage(loadBitmapImage(NEW_BTN_NAME + BTN_FILE_SUFFIX));
        }

        public static BitmapImage loadBitmapImage(string filename) {
            return new BitmapImage(new Uri(RESOURCE_URI + filename, UriKind.Absolute));
        }

        public static Image createImage(BitmapImage btm) {
            Image img = new Image();
            img.Source = btm;
            // [TODO] img.Stretch = Stretch.Fill;
            return img;
        }

        public static void showMsg(string msg) {
            System.Windows.MessageBox.Show(msg);
        }

        // Fisher-Yates shuffle
        public static void Shuffle<T>(this IList<T> list) {
            int n = list.Count;
            while (n > 1) {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }

        // [SC] Pop operation on a list
        public static T Pop<T>(this IList<T> list, int index) {
            if (list.Count > index) {
                T elem = list[index];
                list.RemoveAt(index);
                return elem;
            }
            return default(T);
        }

        // [SC] get a random element from a list
        public static T getRandomElement<T>(this IList<T> list) {
            int n = list.Count;
            if (n == 1) return list[0];
            else if (n > 1) return list[rng.Next(n)];
            else return default(T);
        }

        // [SC] do list shallow cloning
        public static List<T> listShallowClone<T>(this IList<T> list) {
            List<T> cloneList = new List<T>();
            foreach (T listItem in list) {
                cloneList.Add(listItem);
            }
            return cloneList;
        }

        // [SC] create a shallow clone of the 2D array
        public static QwirkleTile[,] createBoardCopy(QwirkleTile[,] tileArray) {
            if (tileArray == null) return null;

            int rowCount = tileArray.GetLength(0);
            int colCount = tileArray.GetLength(1);

            QwirkleTile[,] newTileArray = new QwirkleTile[rowCount, colCount];

            for (int currRowIndex = 0; currRowIndex < rowCount; currRowIndex++) {
                for (int currColIndex = 0; currColIndex < colCount; currColIndex++) {
                    newTileArray[currRowIndex, currColIndex] = tileArray[currRowIndex, currColIndex];
                }
            }

            return newTileArray;
        }

        public static Action EmptyDelegate = delegate() { };
    }
}
