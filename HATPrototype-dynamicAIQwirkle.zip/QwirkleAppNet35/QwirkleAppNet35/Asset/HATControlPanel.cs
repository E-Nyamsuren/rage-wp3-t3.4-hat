﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Asset
Filename: HATControlPanel.cs
Description: Implements the control panel shown on the left of the canvas panel.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // StackPanel
using System.Collections.ObjectModel; // ObservableCollection
using System.Windows; // Thickness
using System.Diagnostics; // Debug

namespace QwirkleAppNet35.Asset 
{
    class HATControlPanel : StackPanel 
    {
        private WidgetWindow widgetWindow;

        private ComboBox adaptCBox;
        private ComboBox gameCBox;

        private ComboBox scenarioCBox;
        private ComboBox playerCBox;

        private ComboBox showRatingsCBox;

        public HATControlPanel(WidgetWindow widgetWindow)
            : base() {
            this.widgetWindow = widgetWindow;
        }

        public void initPanel() {
            this.Width = Cfg.HAT_CONTROL_PANEL_WIDTH;
            //this.Margin = new Thickness { Bottom = Cfg.HAT_CONTROL_PANEL_MARGIN };
            this.Orientation = Orientation.Vertical;

            // [SC] select adaptation type
            Label adaptLabel = new Label();
            adaptLabel.Content = "Select adaptation type:";

            adaptCBox = new ComboBox();
            adaptCBox.SelectionChanged += new SelectionChangedEventHandler(ComboBoxEventHandler);
            adaptCBox.ItemsSource = widgetWindow.getAllAdaptations();

            // [SC] select game
            Label gameLabel = new Label();
            gameLabel.Content = "Select game type:";

            gameCBox = new ComboBox();
            gameCBox.SelectionChanged += new SelectionChangedEventHandler(ComboBoxEventHandler);
            gameCBox.IsEnabled = false;

            // [SC] select scenario
            Label scenarioLabel = new Label();
            scenarioLabel.Content = "Select scenario";

            scenarioCBox = new ComboBox();
            scenarioCBox.SelectionChanged += new SelectionChangedEventHandler(ComboBoxEventHandler);
            scenarioCBox.IsEnabled = false;

            // [SC] select player
            Label playerLabel = new Label();
            playerLabel.Content = "Select player:";

            playerCBox = new ComboBox();
            playerCBox.SelectionChanged += new SelectionChangedEventHandler(ComboBoxEventHandler);
            playerCBox.IsEnabled = false;

            // [SC] select rating type
            Label showRatingsLabel = new Label();
            showRatingsLabel.Content = "Show ratings for:";

            ObservableCollection<string> selectionList = new ObservableCollection<string>();
            selectionList.Add("Scenario");
            selectionList.Add("Player");
            showRatingsCBox = new ComboBox();
            showRatingsCBox.SelectionChanged += new SelectionChangedEventHandler(ComboBoxEventHandler);
            showRatingsCBox.IsEnabled = false;
            showRatingsCBox.ItemsSource = selectionList;

            this.Children.Add(adaptLabel);
            this.Children.Add(adaptCBox);

            this.Children.Add(gameLabel);
            this.Children.Add(gameCBox);

            this.Children.Add(scenarioLabel);
            this.Children.Add(scenarioCBox);

            this.Children.Add(playerLabel);
            this.Children.Add(playerCBox);

            this.Children.Add(showRatingsLabel);
            this.Children.Add(showRatingsCBox);
        }

        private void updateGameCBox(string adaptID) {
            gameCBox.SelectedIndex = -1;
            gameCBox.ItemsSource = widgetWindow.getAllGames(adaptID);
            gameCBox.IsEnabled = true;

            scenarioCBox.IsEnabled = false;
            playerCBox.IsEnabled = false;
        }

        private void updateScenarioCBox(string adaptID, string gameID) {
            scenarioCBox.SelectedIndex = -1;
            scenarioCBox.ItemsSource = widgetWindow.getAllScenarios(adaptID, gameID);
            if (scenarioCBox.ItemsSource != null) {
                (scenarioCBox.ItemsSource as ObservableCollection<string>).Add(QwirkleAppNet35.Data.Cfg.ALL_KEYWORD);
                scenarioCBox.IsEnabled = true;
            }
        }

        private void updatePlayerCBox(string adaptID, string gameID) {
            playerCBox.SelectedIndex = -1;
            playerCBox.ItemsSource = widgetWindow.getAllPlayers(adaptID, gameID);
            if (playerCBox.ItemsSource != null) {
                (playerCBox.ItemsSource as ObservableCollection<string>).Add(QwirkleAppNet35.Data.Cfg.ALL_KEYWORD);
                playerCBox.IsEnabled = true;
            }
        }

        private void ComboBoxEventHandler(object sender, SelectionChangedEventArgs e) {
            ComboBox source = sender as ComboBox;
            if (source == adaptCBox) {
                updateGameCBox(source.SelectedItem as string);
            }
            else if (source == gameCBox) {
                updateScenarioCBox(adaptCBox.SelectedItem as string, gameCBox.SelectedItem as string);
                updatePlayerCBox(adaptCBox.SelectedItem as string, gameCBox.SelectedItem as string);
                showRatingsCBox.IsEnabled = true;
            }
            else if (source == playerCBox || source == scenarioCBox || source == showRatingsCBox) {
                if (scenarioCBox.SelectedIndex != -1 && playerCBox.SelectedIndex != -1 && showRatingsCBox.SelectedIndex != -1) {
                    if ((showRatingsCBox.SelectedItem as string).Equals("Scenario"))
                        widgetWindow.drawScenarioRatings(adaptCBox.SelectedItem as string, gameCBox.SelectedItem as string
                                                        , scenarioCBox.SelectedItem as string, playerCBox.SelectedItem as string);
                    else
                        widgetWindow.drawPlayerRatings(adaptCBox.SelectedItem as string, gameCBox.SelectedItem as string
                                                        , scenarioCBox.SelectedItem as string, playerCBox.SelectedItem as string);
                }

            }
        }
    }
}
