﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.StickersGame
Filename: Game.cs
Description:
    Implements the main logic of the Stickers game.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows; // Window
using System.Threading; // [SC] Thread 

namespace QwirkleAppNet35.StickersGame 
{
    public class Game 
    {
        private StickersGameWindow stickersWindow;

        private Player humanPlayer;
        private Player aiPlayer;

        private int playerSticks;
        private int rounds;

        private bool activeGameFlag;
        private bool newGameInitFlag;

        private bool startRoundFlag;
        private bool endRoundFlag;

        private int currRound;

        private double success;

        public Game(StickersGameWindow stickersWindow) {
            this.stickersWindow = stickersWindow;

            playerSticks = Cfg.DEFAULT_PLAYER_STICKS;
            rounds = Cfg.DEFAULT_ROUNDS;
        }

        public void initNewGame(string humanPlayerID, string aiPlayerID) {
            humanPlayer = new Player(this, humanPlayerID);
            aiPlayer = new Player(this, aiPlayerID);

            currRound = 0;

            success = 0;

            newGameInitFlag = true;
        }

        // [SC] should be called within a worker thread
        public void startNewGame() {
            if (!newGameInitFlag) return;

            if (activeGameFlag) return;

            newGameInitFlag = false;
            activeGameFlag = true;

            startRoundFlag = true;
            endRoundFlag = false;

            while (activeGameFlag) {
                if (startRoundFlag) startNewRound();

                Thread.Sleep(100);

                if (endRoundFlag && aiPlayer.madeCurrChoice() && humanPlayer.madeCurrChoice()) endRound();
            }
        }

        private void startNewRound() {
            currRound++;

            humanPlayer.resetDecision();
            aiPlayer.resetDecision();

            // [SC] asking the ai player to make a choice
            aiPlayer.invokeAI();

            startRoundFlag = false;
            endRoundFlag = true;

            // [SC] notify UI about round start
            stickersWindow.startRoundNotification(currRound, playerSticks);
        }

        public void endRound() {
            int humanChoice = humanPlayer.getCurrChoice();
            int aiChoice = aiPlayer.getCurrChoice();

            int humanScore = humanChoice;
            int aiScore = aiChoice;

            if (humanChoice > aiChoice) {
                Cfg.showMsg("You get 0 for choosing " + humanChoice + ". AI player gets " + aiChoice + ".");
                humanScore = 0;

            }
            else if (humanChoice < aiChoice) {
                Cfg.showMsg("You get " + humanChoice + ". AI player gets 0 for choosing " + aiChoice + ".");
                aiScore = 0;
            }
            else {
                Cfg.showMsg("Both You and AI get 0.");
                humanScore = 0;
                aiScore = 0;
            }

            humanPlayer.setCurrScore(humanScore);
            aiPlayer.setCurrScore(aiScore);

            humanPlayer.recordMyCurrDecision();
            aiPlayer.recordMyCurrDecision();

            aiPlayer.setOtherLastDecision(humanChoice, humanScore);

            endRoundFlag = false;

            // [SC] if true then the last round was played and the game ends
            if (currRound == rounds) {
                activeGameFlag = false;

                if (humanPlayer.getTotalScore() >= aiPlayer.getOtherTotalExpectedScore()) success = 1;
                else success = 0;
            }
            else {
                startRoundFlag = true;
            }

            // [SC] notify UI about round end
            stickersWindow.endRoundNotification(currRound, getInfoText());
        }

        // [SC] to be called by I/O component
        public void setHumanPlayerChoice(int choice) {
            if (humanPlayer.madeCurrChoice()) {
                Cfg.showMsg("You have already made your choice.");
                return;
            }

            int intChoice = isValidChoice(choice);
            if (intChoice != Cfg.NONE) humanPlayer.setCurrChoice(intChoice);
        }

        public string getGoalText() {
            return "You goal is to collect " + aiPlayer.getOtherTotalExpectedScore() + " or more coins."
                    + "\nYou currently collected " + humanPlayer.getTotalScore() + " coins.";
        }

        public string getInfoText() {
            string text = "";

            for (int prevRoundIndex = 0; prevRoundIndex < currRound; prevRoundIndex++) {
                text += "\nRound " + (prevRoundIndex + 1);
                text += "\n    Your choice: " + humanPlayer.getRoundChoice(prevRoundIndex) + "; AI choice: " + aiPlayer.getRoundChoice(prevRoundIndex);
                //text += "\n    Your score: " + humanPlayer.getRoundScore(prevRoundIndex) + "; AI score: " + aiPlayer.getRoundScore(prevRoundIndex);
            }

            return text + "\n" + getGoalText();
        }

        // [SC] verifies if the int value represents a valid choice of sticks
        private int isValidChoice(int choice) {
            if (choice > 0 && choice <= playerSticks)
                return choice;
            else
                return Cfg.NONE;
        }

        public int getAiChoice() {
            return aiPlayer.getCurrChoice();
        }

        public int getRounds() {
            return rounds;
        }

        public int getPlayerSticks() {
            return playerSticks;
        }

        public int getCurrRound() {
            return currRound;
        }

        public bool isActiveGame() {
            return activeGameFlag;
        }

        public double getSuccess() {
            return success;
        }

        public void forceEndGame() {
            activeGameFlag = false;
        }
    }
}
