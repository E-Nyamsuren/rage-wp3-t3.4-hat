﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.StickersGame
Filename: Player.cs
Description:
    Defines a class that implements a player that can be either a contruct for human player or purely AI player.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace QwirkleAppNet35.StickersGame 
{
    public class Player
    {
        private Game game;
        private string playerID;

        private int currChoice;
        private int currScore;

        private List<Decision> myDecisions;
        private Decision otherLastDecison;

        public Player(Game game, string playerID) {
            this.game = game;
            this.playerID = playerID;

            myDecisions = new List<Decision>();
            otherLastDecison = null;

            resetDecision();
        }

        public void resetDecision() {
            resetCurrChoice();
            resetCurrScore();
        }

        public string getPlayerID() {
            return playerID;
        }

        /////////////////////////////////////////////////////////////////////
        ////// START: player's current choice methods 

        // [SC] assumes that the validity of the choice has been verified at the Game level
        public void setCurrChoice(int currChoice) {
            this.currChoice = currChoice;
        }

        public int getCurrChoice() {
            return currChoice;
        }

        public bool madeCurrChoice() {
            if (getCurrChoice() == Cfg.NONE) return false;
            else return true;
        }

        public void resetCurrChoice() {
            setCurrChoice(Cfg.NONE);
        }

        ////// END: player's current choice methods
        /////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////
        ////// START: player's current score methods

        public void setCurrScore(int currScore) {
            this.currScore = currScore;
        }

        public int getCurrScore() {
            return currScore;
        }

        public bool hasCurrScore() {
            if (getCurrScore() == Cfg.NONE) return false;
            else return true;
        }

        public void resetCurrScore() {
            setCurrScore(Cfg.NONE);
        }

        ////// END: player's current score methods
        /////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////
        ////// START: player's decision methods

        public void recordMyCurrDecision() {
            if (madeCurrChoice() && hasCurrScore())
                myDecisions.Add(new Decision(getCurrChoice(), getCurrScore()));
            else
                Cfg.showMsg("Cannot record decision for " + getPlayerID() + ". Either no choice was made or no actual/expected scores were assigned.");
        }

        public Decision getMyLastDecision() {
            if (madePastDecisions()) return myDecisions.Last();
            else return null;
        }

        public bool madePastDecisions() {
            if (myDecisions.Count == 0) return false;
            else return true;
        }

        public int getRoundChoice(int roundIndex) {
            if (roundIndex < myDecisions.Count)
                return myDecisions.ElementAt(roundIndex).getChoice();
            else {
                Cfg.showMsg("Cannot get player's score at indicated round. Invalid round index " + roundIndex);
                return Cfg.NONE;
            }
        }

        public int getRoundScore(int roundIndex) {
            if (roundIndex < myDecisions.Count)
                return myDecisions.ElementAt(roundIndex).getScore();
            else {
                Cfg.showMsg("Cannot get player's score at indicated round. Invalid round index " + roundIndex);
                return Cfg.NONE;
            }
        }

        public int getTotalScore() {
            int totalScore = 0;
            foreach (Decision decision in myDecisions) {
                totalScore += decision.getScore();
            }
            return totalScore;
        }

        ////// START: player's decision methods
        /////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////
        ////// START: other player's decision methods

        public void setOtherLastDecision(int otherCurrChoice, int otherCurrScore) {
            otherLastDecison = new Decision(otherCurrChoice, otherCurrScore);
        }

        public Decision getOtherLastDecision() {
            return otherLastDecison;
        }

        ////// END: other player's decision methods
        /////////////////////////////////////////////////////////////////////

        public void invokeAI() {
            invokeAI(playerID);
        }

        public void invokeAI(string aiPlayerID) {
            switch (aiPlayerID) {
                case Cfg.CONSERVATIVE_AI_ID:
                    invokeConservativeAI();
                    break;
                case Cfg.NAIVE_AI_ID:
                    invokeNaiveAI();
                    break;
                case Cfg.RANDOM_AI_ID:
                    invokeRandomAI();
                    break;
                case Cfg.COOPERAATIVE_AI_ID:
                    invokeCooperativeAI();
                    break;
                case Cfg.TOMONE_AI_ID:
                    invokeToMOneAI();
                    break;
                case Cfg.TOMTWO_AI_ID:
                    invokeToMTwoAI();
                    break;
                default:
                    Cfg.showMsg("Cannot invoke AI. Unknown AI player ID.");
                    break;
            }
        }

        public int getOtherTotalExpectedScore() {
            return getOtherTotalExpectedScore(playerID);
        }

        public int getOtherTotalExpectedScore(string aiPlayerID) {
            switch (aiPlayerID) {
                case Cfg.CONSERVATIVE_AI_ID: return getOtherExpectedTotalScoreConservativeAI();
                case Cfg.NAIVE_AI_ID: return getOtherExpectedTotalScoreNaiveAI();
                case Cfg.RANDOM_AI_ID: return getOtherExpectedTotalScoreRandomAI();
                case Cfg.COOPERAATIVE_AI_ID: return getOtherExpectedTotalScoreCooperativeAI();
                case Cfg.TOMONE_AI_ID: return getOtherExpectedTotalScoreToMOneAI();
                case Cfg.TOMTWO_AI_ID: return getOtherExpectedTotalScoreToMTwoAI();
                default:
                    Cfg.showMsg("Cannot get expected score. Unknown AI player ID.");
                    return Cfg.NONE;
            }
        }

        ///////////////////////////////////////////////////////////////////////////////

        // [SC] always plays 1; optimal move is to always choose 1;
        private void invokeConservativeAI() {
            setCurrChoice(1);
        }

        private int getOtherExpectedTotalScoreConservativeAI() {
            return 0;
        }

        ///////////////////////////////////////////////////////////////////////////////

        // [SC] always plays 5; optimal move is to always choose 4;
        private void invokeNaiveAI() {
            setCurrChoice(game.getPlayerSticks());
        }

        private int getOtherExpectedTotalScoreNaiveAI() {
            return (game.getPlayerSticks() - 1) * game.getRounds();
        }

        ///////////////////////////////////////////////////////////////////////////////

        // [SC] randomly chooses between 1 and 5 stickers
        // [SC] as a score calculate whether the player got higher than the average of both scores
        private void invokeRandomAI() {
            setCurrChoice(Cfg.getRandomNumber(game.getPlayerSticks() + 1));
        }

        private int getOtherExpectedTotalScoreRandomAI() {
            //int targetChoice = 2;
            //return targetChoice * game.getRounds() * (game.getPlayerSticks() - targetChoice) / game.getPlayerSticks();
            return 10;
        }

        ///////////////////////////////////////////////////////////////////////////////

        // [SC] always plays 5 and 4 alternatively, but may change the strategy later if cooperation is not achieved
        private void invokeCooperativeAI() {
            bool coopFlag = true;

            // [SC] decide which strategy to use
            int coopRoundCount = (int)(game.getRounds() * Cfg.COOP_AI_PATIENCE);
            if (coopRoundCount < game.getCurrRound()) {
                int totalScore = 0;
                for (int currIndex = 0; currIndex < (game.getCurrRound() - 1); currIndex++) {
                    totalScore += myDecisions.ElementAt(currIndex).getScore();
                }

                int totalExpectScore = getMyExpectedTotalScoreCooperativeAI(game.getCurrRound() - 1);

                // [SC] if true then cooperative strategy is not working; switch to conservative strategy
                if (totalScore < totalExpectScore) coopFlag = false;
            }

            if (coopFlag) {
                int playerSticks = game.getPlayerSticks();

                if (!madePastDecisions() || getMyLastDecision().getChoice() != playerSticks) setCurrChoice(playerSticks);
                else setCurrChoice(playerSticks - 1);
            }
            else {
                invokeConservativeAI();
            }
        }

        private int getOtherExpectedTotalScoreCooperativeAI() {
            return getOtherExpectedTotalScoreCooperativeAI(game.getRounds());
        }

        private int getOtherExpectedTotalScoreCooperativeAI(int roundCount) {
            const int winScore = 4; // [TODO]
            int totalExpectScore = 0;

            for (int currIndex = 0; currIndex < roundCount; currIndex += 2) {
                totalExpectScore += winScore;
            }

            return totalExpectScore;
        }

        private int getMyExpectedTotalScoreCooperativeAI(int roundCount) {
            const int winScore = 4; // [TODO]
            int totalExpectScore = 0;

            for (int currIndex = 1; currIndex < roundCount; currIndex += 2) {
                totalExpectScore += winScore;
            }

            return totalExpectScore;
        }

        ///////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// - start with second highest number of the sticks
        /// - if win then increase by 1
        /// - if draw with 1 then increase by 1
        /// - if loose then decrease by 1
        /// - never plays the max sticks
        /// AI	Player	Score
        /// 4	3	3
        /// 3	4	0
        /// 4	3	3
        /// 3	4	0
        /// 4	3	3
        /// 3	4	0
        /// 4	3	3
        /// 3	4	0
        /// 4	3	3
        /// 3	4	0
        /// </summary>
        private void invokeToMOneAI() {
            if (madePastDecisions()) {
                Decision myLastDecision = getMyLastDecision();
                if (myLastDecision.getScore() > 0) { // [SC] it was a win
                    if ((myLastDecision.getChoice() + 1) < game.getPlayerSticks()) setCurrChoice(myLastDecision.getChoice() + 1);
                    else setCurrChoice(myLastDecision.getChoice());
                }
                else if (myLastDecision.getChoice() == 1) { // [SC] it was a draw with 1
                    setCurrChoice(myLastDecision.getChoice() + 1);
                }
                else { // [SC] it was a draw with non 1 or loss
                    setCurrChoice(myLastDecision.getChoice() - 1);
                }
            }
            else {
                setCurrChoice(game.getPlayerSticks() - 1);
            }
        }

        private int getOtherExpectedTotalScoreToMOneAI() {
            const int winScore = 3;
            int totalExpectScore = 0;

            for (int currIndex = 0; currIndex < game.getRounds(); currIndex += 2) {
                totalExpectScore += winScore;
            }

            return totalExpectScore;
        }

        ///////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// - start with second highest number of the sticks
        /// - assumes that the human player follows the same strategy as the ToMOneAITwo
        /// - never plays the max sticks
        /// AI	Player	Score
        /// 3	2	2
        /// 2	5	0
        /// 3	2	2
        /// 2	5	0
        /// 3	2	2
        /// 2	5	0
        /// 3	2	2
        /// 2	5	0
        /// 3	2	2
        /// 2	5	0 - 10
        /// </summary>
        private void invokeToMTwoAI() {
            if (madePastDecisions()) {
                if (otherLastDecison.getScore() > 0) { // [SC] human player won; assumme human player will increase by 1
                    if ((otherLastDecison.getChoice() + 1) < game.getPlayerSticks()) setCurrChoice(otherLastDecison.getChoice());
                    else setCurrChoice(otherLastDecison.getChoice() - 1);
                }
                else if (otherLastDecison.getChoice() == 1) { // [SC] it was a draw with 1; assume human player will choose 2
                    setCurrChoice(1);
                }
                else { // [SC] it was a draw with a number higher than 1 or loss for human player; assume human player will choose one less
                    if ((otherLastDecison.getChoice() - 2) >= 1) setCurrChoice(otherLastDecison.getChoice() - 2);
                    else setCurrChoice(1);
                }
            }
            else { // [SC] assumes that humna player will start with the maxSticks - 1
                setCurrChoice(game.getPlayerSticks() - 2);
            }
        }

        private int getOtherExpectedTotalScoreToMTwoAI() {
            const int winScore = 2;
            int totalExpectScore = 0;

            for (int currIndex = 0; currIndex < game.getRounds(); currIndex += 2) {
                totalExpectScore += winScore;
            }

            return totalExpectScore;
        }
    }
}
