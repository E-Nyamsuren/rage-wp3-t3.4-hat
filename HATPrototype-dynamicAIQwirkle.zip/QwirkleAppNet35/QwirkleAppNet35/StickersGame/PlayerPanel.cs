﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.StickersGame
Filename: PlayerPanel.cs
Description:
    UI component. Implements a panel containing images of player's name, avatar and coins.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // StackPanel
using System.Windows; // TextWrapping

namespace QwirkleAppNet35.StickersGame 
{
    public class PlayerPanel : StackPanel 
    {
        private StickersGameWindow stickersWindow;

        private StackPanel mainPanel;
        private StackPanel bottomPanel;

        private Label playerLabel;
        private List<Image> coins;

        public PlayerPanel(StickersGameWindow stickersWindow) : base() {
            this.stickersWindow = stickersWindow;

            mainPanel = new StackPanel();

            // [SC] creating a border around the main panel
            Border mainBorder = new Border();
            mainBorder.BorderBrush = System.Windows.Media.Brushes.Black;
            mainBorder.BorderThickness = new Thickness(1);
            mainBorder.Child = mainPanel;
            this.Children.Add(mainBorder);
        }

        public void initPanel(string playerID, bool isHuman, int playerStickers) {
            mainPanel.Children.Clear();

            mainPanel.Orientation = Orientation.Vertical;
            mainPanel.Width = Cfg.PLAYER_IMAGE_WIDTH_HEGHT[0] + (Cfg.COIN_IMAGE_WIDTH_HEGHT[0] * playerStickers);
            mainPanel.Background = System.Windows.Media.Brushes.Gray;

            playerLabel = new Label();
            playerLabel.Width = this.Width;
            playerLabel.Height = Cfg.PLAYER_MSG_WIDTH_HEIGHT[1];
            mainPanel.Children.Add(playerLabel);

            // [SC] creating a bottom panel
            bottomPanel = new StackPanel();
            bottomPanel.Orientation = Orientation.Horizontal;
            bottomPanel.Background = System.Windows.Media.Brushes.White;

            Image playerImage = Cfg.getPlayerImage(playerID);
            playerImage.Width = Cfg.PLAYER_IMAGE_WIDTH_HEGHT[0];
            playerImage.Height = Cfg.PLAYER_IMAGE_WIDTH_HEGHT[1];
            bottomPanel.Children.Add(playerImage);

            mainPanel.Children.Add(bottomPanel);

            coins = new List<Image>();

            addCoins(playerStickers);
        }

        public void addCoins(int playerStickers) {
            int currCoinCount = coins.Count;
            for (int currCoinIndex = 0; currCoinIndex < (playerStickers - currCoinCount); currCoinIndex++) {
                Image coinImage = Cfg.getCoinImage();
                coinImage.Width = Cfg.COIN_IMAGE_WIDTH_HEGHT[0];
                coinImage.Height = Cfg.COIN_IMAGE_WIDTH_HEGHT[1];
                coins.Add(coinImage);
                bottomPanel.Children.Add(coinImage);
            }
        }

        public Image removeCoin() {
            Image coinImage = coins.Pop<Image>(0);
            bottomPanel.Children.Remove(coinImage);
            return coinImage;
        }

        public void setPlayerMsg(string msg) {
            if (playerLabel == null) return;

            playerLabel.Content = msg;
        }
    }
}
