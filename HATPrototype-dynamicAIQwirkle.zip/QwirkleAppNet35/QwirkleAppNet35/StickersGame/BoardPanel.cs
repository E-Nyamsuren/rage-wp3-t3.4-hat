﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.StickersGame
Filename: BoardPanel.cs
Description:
    UI component. Implements the board between two player where the coins are placed at the end of the round.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // StackPanel

namespace QwirkleAppNet35.StickersGame 
{
    class BoardPanel : StackPanel
    {
        private StickersGameWindow stickersWindow;
        private StackPanel humanPanel;
        private StackPanel aiPanel;

        public BoardPanel(StickersGameWindow stickersWindow)
            : base() {
            this.stickersWindow = stickersWindow;
        }

        public void initPanel(int playerStickers) {
            this.Children.Clear();

            this.Orientation = Orientation.Vertical;

            aiPanel = new StackPanel();
            aiPanel.Width = Cfg.COIN_IMAGE_WIDTH_HEGHT[0] * playerStickers;
            aiPanel.Height = Cfg.COIN_IMAGE_WIDTH_HEGHT[1];
            aiPanel.Orientation = Orientation.Horizontal;
            //aiPanel.Background = System.Windows.Media.Brushes.Aqua;
            this.Children.Add(aiPanel);

            humanPanel = new StackPanel();
            humanPanel.Width = Cfg.COIN_IMAGE_WIDTH_HEGHT[0] * playerStickers;
            humanPanel.Height = Cfg.COIN_IMAGE_WIDTH_HEGHT[1];
            humanPanel.Orientation = Orientation.Horizontal;
            //humanPanel.Background = System.Windows.Media.Brushes.SeaGreen;
            this.Children.Add(humanPanel);
        }

        public void addHumanCoin(Image coinImage) {
            humanPanel.Children.Add(coinImage);
        }

        public void addHumanCoin() {
            Image coinImage = Cfg.getCoinImage();
            coinImage.Width = Cfg.COIN_IMAGE_WIDTH_HEGHT[0];
            coinImage.Height = Cfg.COIN_IMAGE_WIDTH_HEGHT[1];
            addHumanCoin(coinImage);
        }

        public void addAICoin(Image coinImage) {
            aiPanel.Children.Add(coinImage);
        }

        public void addAICoin() {
            Image coinImage = Cfg.getCoinImage();
            coinImage.Width = Cfg.COIN_IMAGE_WIDTH_HEGHT[0];
            coinImage.Height = Cfg.COIN_IMAGE_WIDTH_HEGHT[1];
            addAICoin(coinImage);
        }

        public void clearCoins() {
            humanPanel.Children.Clear();
            aiPanel.Children.Clear();
        }
    }
}
