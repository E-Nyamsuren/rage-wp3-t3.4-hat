﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.StickersGame
Filename: Cfg.cs
Description:
    Contains configurational settings as constants, static variables and static utility methods for the Stickers game.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // [SC] For using Image class.
using System.Windows.Media.Imaging; // BitmapImage

namespace QwirkleAppNet35.StickersGame {
    public static class Cfg 
    {
        public const string GAME_ID = "Stickers";

        private static Random rng = new Random();

        public const int DEFAULT_PLAYER_STICKS = 5;
        public const int NONE = -1;

        public const int DEFAULT_ROUNDS = 10;

        public const string CONSERVATIVE_AI_ID = "Troll";
        public const string NAIVE_AI_ID = "Ogre"; // http://orig10.deviantart.net/8ac7/f/2012/187/3/8/goblin__s_tale_ogre_redesign_by_mr_goblin-d568wj4.png
        public const string RANDOM_AI_ID = "Pirate"; // http://www.piratesglory.com/images/concept_art/?Qwd=.&Qif=Pirate%20Cartoon.gif&Qiv=name&Qis=M
        public const string COOPERAATIVE_AI_ID = "Knight"; // http://jdeberge.deviantart.com/art/Dark-Souls-Oscar-Knight-of-Astora-433206042
        public const string TOMONE_AI_ID = "Mage"; // http://artoftrav.com/imageDisplay.php?id=8
        public const string TOMTWO_AI_ID = "Engineer"; // http://windmaker.deviantart.com/art/Gnome-Tinkerer-449115596

        public const double COOP_AI_PATIENCE = 0.5;


        public const string RESOURCE_URI = "pack://application:,,,/resources/";
        public const string COIN_FILENAME = "coin.png";

        public static int[] PLAYER_IMAGE_WIDTH_HEGHT = { 120, 200 };
        public static int[] COIN_IMAGE_WIDTH_HEGHT = { 50, 50 };

        public static int[] PLAYER_MSG_WIDTH_HEIGHT = { 150, 40 };

        /////////////////////////////////////////////////////////////////

        public const string CONFIRM_BTN_NAME = "confirmChoice";
        public const string NEW_GAME_BTN_NAME = "newGame";

        public const int SCORE_BOX_HEIGHT = 400;
        public const int SCORE_BOX_WIDTH = 250;

        /////////////////////////////////////////////////////////////////

        public static string getAIMessage(string aiID) {
            switch (aiID) {
                case CONSERVATIVE_AI_ID: return "Muhahaha.";
                case NAIVE_AI_ID: return "Coins?!";
                case RANDOM_AI_ID: return "My thoughts are all random because of rum.";
                case COOPERAATIVE_AI_ID: return "I don't like competition.";
                case TOMONE_AI_ID: return "I shall carefully record my moves.";
                case TOMTWO_AI_ID: return "I am smarter than the " + TOMONE_AI_ID + ".\nI know what you are thinking.";
                default: return "Unknown player";
            }
        }

        public static string getPlayerImageFilename(string playerID) {
            switch (playerID) {
                case CONSERVATIVE_AI_ID: return "troll.png";
                case NAIVE_AI_ID: return "ogre.png";
                case RANDOM_AI_ID: return "pirate.png";
                case COOPERAATIVE_AI_ID: return "knight.png";
                case TOMONE_AI_ID: return "mage.png";
                case TOMTWO_AI_ID: return "engineer.png";
                default: return "ghost.png"; // http://alisonwonderland1951.deviantart.com/art/The-Pac-Man-Ghosts-350424344
            }
        }

        public static int getRandomNumber(int maxNumber) {
            int randomNum;
            while ((randomNum = rng.Next(maxNumber)) == 0) ;
            return randomNum;
        }

        public static void showMsg(string msg) {
            System.Windows.MessageBox.Show(msg);
        }

        public static Image getCoinImage() {
            return createImage(loadBitmapImage(COIN_FILENAME));
        }

        public static Image getPlayerImage(string playerID) {
            return createImage(loadBitmapImage(getPlayerImageFilename(playerID)));
        }

        public static BitmapImage loadBitmapImage(string filename) {
            return new BitmapImage(new Uri(RESOURCE_URI + filename, UriKind.Absolute));
        }

        public static Image createImage(BitmapImage btm) {
            Image img = new Image();
            img.Source = btm;
            // [TODO] img.Stretch = Stretch.Fill;
            return img;
        }

        // [SC] Pop operation on a list
        public static T Pop<T>(this IList<T> list, int index) {
            if (list.Count > index) {
                T elem = list[index];
                list.RemoveAt(index);
                return elem;
            }
            return default(T);
        }
    }
}
