﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleApp
Filename: MainWindow.cs
Description:
    Implements the main window of the application.
Disclaimer:
    Qwirkle is an intelectual property of and trademarked by MindWare, Inc (http://www.mindware.com/).
    The author of this source code does not claim intelectual property rights to Qwirkle.
    The game is used for non-comercial education purpose only.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows;
using System.Windows.Controls;

using System.Collections.ObjectModel; // ObservableCollection
using System.Diagnostics; // Debug
using System.ComponentModel; // CancelEventArgs
using System.IO; // Path

/*using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;*/

using QwirkleAppNet35.Asset;
using QwirkleAppNet35.Data;
using QwirkleAppNet35.Game;
using QwirkleAppNet35.StickersGame;

namespace QwirkleAppNet35 {
    public partial class MainWindow : Window {

        private DataManager dataManager;
        private DifficultyAdapter da;

        private TextBox selectDatapathTB;
        private Button selectDatapathBtn;

        private ComboBox adaptCBox;
        private ComboBox gameCBox;

        private TextBox newPlayerTB;
        private Button newPlayerBtn;
        private Button callVisWidgetBtn;

        private ComboBox playerCBox;
        private Button startGameBtn;

        public MainWindow() {
            InitializeComponent();

            Title = "Qwirkle";

            init();

            Show();
        }

        private void init() {
            initResources();

            initUI();

            Closing += doClosingStuff;
        }

        private void initResources() {
            dataManager = new DataManager();
            da = new DifficultyAdapter(this);
        }

        private void initUI() {
            DockPanel mainDockPanel = new DockPanel();
            mainDockPanel.LastChildFill = true;

            /////////////////////////////////////////////////////////////////

            Border topBorder = new Border();
            DockPanel.SetDock(topBorder, Dock.Top);

            StackPanel topMainStackPanel = new StackPanel();
            topMainStackPanel.Orientation = Orientation.Vertical;
            topMainStackPanel.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            // [SC] select datapath
            StackPanel topSubPanelOne = new StackPanel();
            topSubPanelOne.Orientation = Orientation.Horizontal;
            topSubPanelOne.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            selectDatapathTB = new TextBox { Width = Cfg.MAX_LABEL_WIDTH };
            selectDatapathTB.IsEnabled = false;

            selectDatapathBtn = new Button();
            selectDatapathBtn.Name = Cfg.SELECT_DATAPATH_BTN_NAME;
            selectDatapathBtn.Content = "Select datapath";
            selectDatapathBtn.Click += new RoutedEventHandler(selectDatapathButtonClick);
            selectDatapathBtn.IsEnabled = true;
            selectDatapathBtn.HorizontalAlignment = HorizontalAlignment.Center;

            topSubPanelOne.Children.Add(selectDatapathTB);
            topSubPanelOne.Children.Add(selectDatapathBtn);

            topMainStackPanel.Children.Add(topSubPanelOne);

            // [SC] select adaptation type
            StackPanel topSubPanelTwo = new StackPanel();
            topSubPanelTwo.Orientation = Orientation.Horizontal;
            topSubPanelTwo.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            Label selectAdaptL = new Label { Content = "Select adaptation type:" };

            adaptCBox = new ComboBox();
            adaptCBox.SelectionChanged += new SelectionChangedEventHandler(AdaptComboBoxEventHandler);
            adaptCBox.IsEnabled = false;

            topSubPanelTwo.Children.Add(selectAdaptL);
            topSubPanelTwo.Children.Add(adaptCBox);

            topMainStackPanel.Children.Add(topSubPanelTwo);

            // [SC] select a game
            StackPanel topSubPanelThree = new StackPanel();
            topSubPanelThree.Orientation = Orientation.Horizontal;
            topSubPanelThree.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            Label selectGameL = new Label { Content = "Select a game:" };

            gameCBox = new ComboBox();
            gameCBox.SelectionChanged += new SelectionChangedEventHandler(GameComboBoxEventHandler);
            gameCBox.IsEnabled = false;

            topSubPanelThree.Children.Add(selectGameL);
            topSubPanelThree.Children.Add(gameCBox);

            topMainStackPanel.Children.Add(topSubPanelThree);

            topBorder.Child = topMainStackPanel;

            mainDockPanel.Children.Add(topBorder);

            /////////////////////////////////////////////////////////////////

            Border leftBorder = new Border();
            DockPanel.SetDock(leftBorder, Dock.Left);

            StackPanel leftStackPanel = new StackPanel();
            leftStackPanel.Orientation = Orientation.Vertical;
            leftStackPanel.Width = Cfg.LEFT_PANEL_WIDTH;
            leftStackPanel.Margin = new Thickness { Right = Cfg.PANEL_SIDE_MARGIN, Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            // [SC] create new player
            Label newPlayerL = new Label { Content = "Create new player: " };

            newPlayerTB = new TextBox();
            newPlayerTB.MaxLines = 1;
            newPlayerTB.IsEnabled = false;

            newPlayerBtn = new Button();
            newPlayerBtn.Name = Cfg.NEW_PLAYER_BTN_NAME;
            newPlayerBtn.Content = "Create Player";
            newPlayerBtn.Click += new RoutedEventHandler(newPlayerButtonClick);
            newPlayerBtn.IsEnabled = false;
            newPlayerBtn.HorizontalAlignment = HorizontalAlignment.Center;

            callVisWidgetBtn = new Button();
            callVisWidgetBtn.Name = Cfg.VIS_WIDGET_BTN_NAME;
            callVisWidgetBtn.Content = "Call visualization widget";
            callVisWidgetBtn.Click += new RoutedEventHandler(callVisWidgetButtonClick);
            callVisWidgetBtn.IsEnabled = false;
            callVisWidgetBtn.Margin = new Thickness { Top = Cfg.PANEL_BOTTOM_MARGIN };
            callVisWidgetBtn.HorizontalAlignment = HorizontalAlignment.Center;

            leftStackPanel.Children.Add(newPlayerL);
            leftStackPanel.Children.Add(newPlayerTB);
            leftStackPanel.Children.Add(newPlayerBtn);
            leftStackPanel.Children.Add(callVisWidgetBtn);

            leftBorder.Child = leftStackPanel;

            mainDockPanel.Children.Add(leftBorder);

            /////////////////////////////////////////////////////////////////
            // [2015.08.24]
            Border rightBorder = new Border();
            DockPanel.SetDock(rightBorder, Dock.Right);

            StackPanel rightStackPanel = new StackPanel();
            rightStackPanel.Orientation = Orientation.Vertical;
            rightStackPanel.Width = Cfg.RIGHT_PANEL_WIDTH;
            rightStackPanel.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            // [SC] select player
            Label selectPlayerL = new Label { Content = "Select player:" };

            playerCBox = new ComboBox();
            playerCBox.IsEnabled = false;

            startGameBtn = new Button();
            startGameBtn.Name = Cfg.START_GAME_BTN_NAME;
            startGameBtn.Content = "Start game";
            startGameBtn.Click += new RoutedEventHandler(startGameButtonClick);
            startGameBtn.IsEnabled = false;
            startGameBtn.HorizontalAlignment = HorizontalAlignment.Center;

            rightStackPanel.Children.Add(selectPlayerL);
            rightStackPanel.Children.Add(playerCBox);
            rightStackPanel.Children.Add(startGameBtn);

            rightBorder.Child = rightStackPanel;

            mainDockPanel.Children.Add(rightBorder);

            /////////////////////////////////////////////////////////////////

            this.Content = mainDockPanel;

            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        // [2015.08.24]
        private void updateGameCBox(string adaptID) {
            gameCBox.SelectedIndex = -1;
            gameCBox.ItemsSource = dataManager.getAllGames(adaptID);
            gameCBox.IsEnabled = true;
        }

        // [2015.08.24]
        private void updatePlayerCBox(string adaptID, string gameID) {
            playerCBox.SelectedIndex = -1;
            playerCBox.ItemsSource = dataManager.getAllPlayers(adaptID, gameID);
            playerCBox.IsEnabled = true;
        }

        // [2015.08.24]
        private void AdaptComboBoxEventHandler(object sender, SelectionChangedEventArgs e) {
            updateGameCBox(adaptCBox.SelectedItem as string);

            newPlayerTB.IsEnabled = false;
            newPlayerBtn.IsEnabled = false;
            startGameBtn.IsEnabled = false;
        }

        // [2015.08.24]
        private void GameComboBoxEventHandler(object sender, SelectionChangedEventArgs e) {
            updatePlayerCBox(adaptCBox.SelectedItem as string, gameCBox.SelectedItem as string);

            newPlayerTB.IsEnabled = true;
            newPlayerBtn.IsEnabled = true;
            startGameBtn.IsEnabled = true;
        }

        // [SC] event handler for selectDatapathBtn button
        private void selectDatapathButtonClick(object sender, RoutedEventArgs e) {
            System.Windows.Forms.FolderBrowserDialog folderDialog = new System.Windows.Forms.FolderBrowserDialog();
            folderDialog.RootFolder = Environment.SpecialFolder.Desktop;
            folderDialog.SelectedPath = AppDomain.CurrentDomain.BaseDirectory;
            System.Windows.Forms.DialogResult result = folderDialog.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK) {
                string folderName = folderDialog.SelectedPath + "\\";
                selectDatapathTB.Text = folderName;

                // [SC] save and close the data stream if it already was opened
                if (dataManager.hasOpenDatasteam()) dataManager.closeDatastream();
                adaptCBox.IsEnabled = false;
                adaptCBox.ItemsSource = null;

                // [SC] check if new data stream was opened successfully
                if (dataManager.openDatastream(folderName)) {
                    adaptCBox.IsEnabled = true;
                    adaptCBox.ItemsSource = dataManager.getAllAdaptations();
                    callVisWidgetBtn.IsEnabled = true; // [2015.08.24]
                }
            }
        }

        private void newPlayerButtonClick(object sender, RoutedEventArgs e) {
            if (newPlayerTB.Text == null || newPlayerTB.Text.Equals("")) {
                Cfg.showMsg("Enter player name in the textbox.");
                return;
            }

            // [TODO] check that player name contains valid symbols only

            string adaptID = adaptCBox.SelectedItem as string;
            string gameID = gameCBox.SelectedItem as string; // [2015.08.24]

            addPlayer(adaptID, gameID, newPlayerTB.Text); // [2015.08.24]

            newPlayerTB.Text = null;
            updatePlayerCBox(adaptID, gameID); // [2015.08.24]
        }

        private void callVisWidgetButtonClick(object sender, RoutedEventArgs e) {
            Hide();
            try {
                WidgetWindow ww = new WidgetWindow(this);
            }
            catch (Exception) {
                Show();
            }
        }

        private void startGameButtonClick(object sender, RoutedEventArgs e) {
            if (adaptCBox.SelectedItem == null) {
                Cfg.showMsg("Select an Adaptation.");
                return;
            }

            if (gameCBox.SelectedItem == null) {
                Cfg.showMsg("Select a game.");
                return;
            }

            if (playerCBox.SelectedItem == null) {
                Cfg.showMsg("Select a player.");
                return;
            }

            string adaptID = adaptCBox.SelectedItem as string;
            string gameID = gameCBox.SelectedItem as string;
            string playerID = playerCBox.SelectedItem as string;

            switch (gameID) {
                case QwirkleAppNet35.Game.Cfg.GAME_ID:
                    QwirkleGameWindow qwirkleWindow = new QwirkleGameWindow(this);
                    qwirkleWindow.startNewGame(adaptID, playerID);
                    break;
                case QwirkleAppNet35.StickersGame.Cfg.GAME_ID:
                    StickersGameWindow stickersWindow = new StickersGameWindow(this);
                    stickersWindow.startNewGame(adaptID, playerID);
                    break;
                default:
                    Cfg.showMsg("Unknown game.");
                    break;
            }

            Hide();
        }

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: called by QwirkleGameWindow and StickersGameWindow
        public string getTargetScenarioID(string adaptID, string gameID, string playerID) {
            return da.getTargetScenarioID(adaptID, gameID, playerID); // [2015.08.24]
        }

        public void updateRatings(string adaptID, string gameID, string playerID, string scenarioID, double rt, double correctAnswer) {
            da.updateRatings(adaptID, gameID, playerID, scenarioID, rt, correctAnswer); // [2015.08.24]
        }
        ////// END: called by QwirkleGameWindow
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: called by WidgetWindow
        public ObservableCollection<string> getAllAdaptations() {
            return dataManager.getAllAdaptations();
        }

        public ObservableCollection<string> getAllGames(string adaptID) {
            return dataManager.getAllGames(adaptID);
        }

        public ObservableCollection<string> getAllScenarios(string adaptID, string gameID) {
            return dataManager.getAllScenarios(adaptID, gameID);
        }

        public ObservableCollection<string> getAllPlayers(string adaptID, string gameID) {
            return dataManager.getAllPlayers(adaptID, gameID);
        }

        public List<Point> getPlayerRatingChanges(string adaptID, string gameID, string scenarioID, string playerID) {
            return dataManager.getPlayerRatingChanges(adaptID, gameID, scenarioID, playerID, true);
        }

        public List<Point> getScenarioRatingChanges(string adaptID, string gameID, string scenarioID, string playerID) {
            return dataManager.getScenarioRatingChanges(adaptID, gameID, scenarioID, playerID, true);
        }
        ////// END: called by WidgetWindow
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: called by DifficultyAdapter, MainWindow
        public bool createNewRecord(string adaptID, string gameID, string playerID, string scenarioID
                                    , double rt, double accuracy, double userRating, double scenarioRating, string timestamp) {
            return dataManager.createNewRecord(adaptID, gameID, playerID, scenarioID, rt, accuracy, userRating, scenarioRating, timestamp);
        }

        ////////////////////////////////////////////////////////////////////////////////////
        ////// ////// START: player data getters
        public bool addPlayer(string adaptID, string gameID, string playerID) {
            return dataManager.addPlayer(adaptID, gameID, playerID, da.ProvTheta, 0, da.KConst, da.ProvU, da.ProvDate);
        }

        public bool addPlayer(string adaptID, string gameID, string playerID, double rating, double playCount, double kFactor, double uncertainty, string date) {
            return dataManager.addPlayer(adaptID, gameID, playerID, rating, playCount, kFactor, uncertainty, date);
        }

        public string getPlayerRating(string adaptID, string gameID, string playerID) {
            return dataManager.getPlayerRating(adaptID, gameID, playerID);
        }

        public string getPlayerPlayCount(string adaptID, string gameID, string playerID) {
            return dataManager.getPlayerPlayCount(adaptID, gameID, playerID);
        }

        public string getPlayerKFct(string adaptID, string gameID, string playerID) {
            return dataManager.getPlayerKFct(adaptID, gameID, playerID);
        }

        public string getPlayerUncertainty(string adaptID, string gameID, string playerID) {
            return dataManager.getPlayerUncertainty(adaptID, gameID, playerID);
        }

        public string getPlayerLastPlayed(string adaptID, string gameID, string playerID) {
            return dataManager.getPlayerLastPlayed(adaptID, gameID, playerID);
        }
        ////// ////// END: player data getters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// ////// START: scenario data getters
        public string getScenarioRating(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioRating(adaptID, gameID, scenarioID);
        }

        public string getScenarioPlayCount(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioPlayCount(adaptID, gameID, scenarioID);
        }

        public string getScenarioKFct(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioKFct(adaptID, gameID, scenarioID);
        }

        public string getScenarioUncertainty(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioUncertainty(adaptID, gameID, scenarioID);
        }

        public string getScenarioLastPlayed(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioLastPlayed(adaptID, gameID, scenarioID);
        }

        public string getScenarioTimeLimit(string adaptID, string gameID, string scenarioID) {
            return dataManager.getScenarioTimeLimit(adaptID, gameID, scenarioID);
        }
        ////// ////// END: scenario data getters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// ////// START: player data setters
        public bool setPlayerPlayCount(string adaptID, string gameID, string playerID, double newPlayCount) {
            return dataManager.setPlayerPlayCount(adaptID, gameID, playerID, newPlayCount);
        }

        public bool setPlayerRating(string adaptID, string gameID, string playerID, double newRating) {
            return dataManager.setPlayerRating(adaptID, gameID, playerID, newRating);
        }

        public bool setPlayerKFct(string adaptID, string gameID, string playerID, double newKFct) {
            return dataManager.setPlayerKFct(adaptID, gameID, playerID, newKFct);
        }

        public bool setPlayerUncertainty(string adaptID, string gameID, string playerID, double newUncertianty) {
            return dataManager.setPlayerUncertainty(adaptID, gameID, playerID, newUncertianty);
        }

        public bool setPlayerLastPlayed(string adaptID, string gameID, string playerID, string newLastPlayed) {
            return dataManager.setPlayerLastPlayed(adaptID, gameID, playerID, newLastPlayed);
        }
        ////// ////// END: player data setters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// ////// START: scenario data setters
        public bool setScenarioRating(string adaptID, string gameID, string scenarioID, double newRating) {
            return dataManager.setScenarioRating(adaptID, gameID, scenarioID, newRating);
        }

        public bool setScenarioPlayCount(string adaptID, string gameID, string scenarioID, double newPlayCount) {
            return dataManager.setScenarioPlayCount(adaptID, gameID, scenarioID, newPlayCount);
        }

        public bool setScenarioKFct(string adaptID, string gameID, string scenarioID, double newKFct) {
            return dataManager.setScenarioKFct(adaptID, gameID, scenarioID, newKFct);
        }

        public bool setScenarioUncertainty(string adaptID, string gameID, string scenarioID, double newUncertianty) {
            return dataManager.setScenarioUncertainty(adaptID, gameID, scenarioID, newUncertianty);
        }

        public bool setScenarioLastPlayed(string adaptID, string gameID, string scenarioID, string newLastPlayed) {
            return dataManager.setScenarioLastPlayed(adaptID, gameID, scenarioID, newLastPlayed);
        }

        public bool setScenarioTimeLimit(string adaptID, string gameID, string scenarioID, double timeLimit) {
            return dataManager.setScenarioTimeLimit(adaptID, gameID, scenarioID, timeLimit);
        }
        ////// ////// END: scenario data setters
        ////////////////////////////////////////////////////////////////////////////////////

        ////// END: called by DifficultyAdapter
        ////////////////////////////////////////////////////////////////////////////////////

        public void doClosingStuff(object sender, CancelEventArgs e) {
            dataManager.closeDatastream();
        }
    }
}

// [TODO] turn timer
// [TODO] make sure RT and accuracy are accurately measured
// [TODO] start new game
// [TODO] improve UI look (button sizes, axis labels in graphs, etc.)
// [TODO] adjust starting tiles
