﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Asset
Filename: DifficultyAdapter.cs
Description: 
    The asset implements ELO-based difficulty to skill adaptation algorithm described in "Klinkenberg, S., Straatemeier, M., & Van der Maas, H. L. J. (2011). 
    Computer adaptive practice of maths ability using a new item response model for on the fly ability and difficulty estimation. 
    Computers & Education, 57 (2), 1813-1824.".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics; // Debug
using System.Collections.ObjectModel; // ObservableCollection

namespace QwirkleAppNet35.Asset
{
    public class DifficultyAdapter
    {
        //// [TODO][SC perhaps all getter/setter functions should just assign default values instead of throwing exceptions

        private const double DEF_MAX_PLAY = 40; // [SC] The default value for the max number of administrations that should result in minimum uncertaint in item's or player's ratings
        private const double DEF_MAX_DELAY = 30; // [SC] The default value for the max number of days after which player's or item's undertainty reaches the maximum

        private const double DEF_K = 0.0075; // [SC] The default value for the K constant
        private const double DEF_K_UP = 4.0; // [SC] the default value for the upward uncertainty weight
        private const double DEF_K_DOWN = 0.5; // [SC] The default value for the downward uncertainty weight

        private const double DEF_U = 1.0; // [SC] The default value for the provisional uncertainty to be assigned to an item or player

        private const string DEF_DATE = "2015/01/01 01:01:01";

        private const double TARGET_DISTR_MEAN = 0.75;
        private const double TARGET_DISTR_SD = 0.1;
        private const double TARGET_UPPER_LIMIT = 1;
        private const double TARGET_LOWER_LIMIT = 0.5;

        private const double DEF_THETA = 0;

        //// [TODO][SC] need to setup getter and setters as well as proper value validity checks
        private double maxPlay;
        private double maxDelay;

        private double kConst;
        private double kUp;
        private double kDown;

        private double provU;

        private string provDate;

        private MainWindow mainWindow;

        // [SC] Assign default values if max play frequency and max non-play delay values are not provided
        public DifficultyAdapter(MainWindow mainWindow) {
            maxPlay = DEF_MAX_PLAY;
            maxDelay = DEF_MAX_DELAY;

            kConst = DEF_K;
            kUp = DEF_K_UP;
            kDown = DEF_K_DOWN;

            provU = DEF_U;

            provDate = DEF_DATE;

            this.mainWindow = mainWindow;
        }

        public void updateRatings(string adaptID, string gameID, string playerID, string scenarioID, double rt, double correctAnswer) {
            // [SC] getting player data
            string playerRatingStr = mainWindow.getPlayerRating(adaptID, gameID, playerID);
            string playerPlayCountStr = mainWindow.getPlayerPlayCount(adaptID, gameID, playerID);
            string playerUncertaintyStr = mainWindow.getPlayerUncertainty(adaptID, gameID, playerID);
            string playerLastPlayedStr = mainWindow.getPlayerLastPlayed(adaptID, gameID, playerID);

            if (playerRatingStr == null || playerPlayCountStr == null
                || playerUncertaintyStr == null || playerLastPlayedStr == null) {
                Debug.WriteLine("Cannot calculate new ratings. Player data is missing.");
                return;
            }

            // [SC] getting scenario data
            string scenarioRatingStr = mainWindow.getScenarioRating(adaptID, gameID, scenarioID);
            string scenarioPlayCountStr = mainWindow.getScenarioPlayCount(adaptID, gameID, scenarioID);
            string scenarioUncertaintyStr = mainWindow.getScenarioUncertainty(adaptID, gameID, scenarioID);
            string scenarioLastPlayedStr = mainWindow.getScenarioLastPlayed(adaptID, gameID, scenarioID);
            string scenarioTimeLimitStr = mainWindow.getScenarioTimeLimit(adaptID, gameID, scenarioID);

            if (scenarioRatingStr == null || scenarioPlayCountStr == null
                || scenarioUncertaintyStr == null || scenarioTimeLimitStr == null || scenarioLastPlayedStr == null) {
                Debug.WriteLine("Cannot calculate new ratings. Scenario data is missing.");
                return;
            }

            DateTime currDateTime = DateTime.UtcNow;
            string currDateTimeStr = currDateTime.ToString(Cfg.TIMESTAMP_FORMAT);

            // [SC] parsing player data
            double playerRating = Double.Parse(playerRatingStr);
            double playerPlayCount = Double.Parse(playerPlayCountStr);
            double playerUncertainty = Double.Parse(playerUncertaintyStr);
            DateTime playerLastPlayed = DateTime.ParseExact(playerLastPlayedStr, Cfg.TIMESTAMP_FORMAT, null);
            double playerLastPlayedDays = (currDateTime - playerLastPlayed).Days;
            if (playerLastPlayedDays > DEF_MAX_DELAY) playerLastPlayedDays = maxDelay;

            // [SC] parsing scenario data
            double scenarioRating = Double.Parse(scenarioRatingStr);
            double scenarioPlayCount = Double.Parse(scenarioPlayCountStr);
            double scenarioUncertainty = Double.Parse(scenarioUncertaintyStr);
            double scenarioTimeLimit = Double.Parse(scenarioTimeLimitStr);
            DateTime scenarioLastPlayed = DateTime.ParseExact(scenarioLastPlayedStr, Cfg.TIMESTAMP_FORMAT, null);
            double scenarioLastPlayedDays = (currDateTime - scenarioLastPlayed).Days;
            if (scenarioLastPlayedDays > DEF_MAX_DELAY) scenarioLastPlayedDays = maxDelay;

            // [SC] calculating actual and expected scores
            double actualScore = calcActualScore(correctAnswer, rt, scenarioTimeLimit);
            double expectScore = calcExpectedScore(playerRating, scenarioRating, scenarioTimeLimit);

            // [SC] calculating player and scenario uncertainties
            double playerNewUncertainty = calcThetaUncertainty(playerUncertainty, playerLastPlayedDays);
            double scenarioNewUncertainty = calcBetaUncertainty(scenarioUncertainty, scenarioLastPlayedDays);

            // [SC] calculating player and sceario K factors
            double playerNewKFct = calcThetaKFctr(playerNewUncertainty, scenarioNewUncertainty);
            double scenarioNewKFct = calcBetaKFctr(playerNewUncertainty, scenarioNewUncertainty);

            // [SC] calculating player and scenario ratings
            double playerNewRating = calcTheta(playerRating, playerNewKFct, actualScore, expectScore);
            double scenarioNewRating = calcBeta(scenarioRating, scenarioNewKFct, actualScore, expectScore);

            // [SC] updating player and scenario play counts
            double playerNewPlayCount = playerPlayCount + 1;
            double scenarioNewPlayCount = scenarioPlayCount + 1;

            // [SC] storing updated player data
            mainWindow.setPlayerRating(adaptID, gameID, playerID, playerNewRating);
            mainWindow.setPlayerPlayCount(adaptID, gameID, playerID, playerNewPlayCount);
            mainWindow.setPlayerKFct(adaptID, gameID, playerID, playerNewKFct);
            mainWindow.setPlayerUncertainty(adaptID, gameID, playerID, playerNewUncertainty);
            mainWindow.setPlayerLastPlayed(adaptID, gameID, playerID, currDateTimeStr);

            // [SC] storing updated scenario data
            mainWindow.setScenarioRating(adaptID, gameID, scenarioID, scenarioNewRating);
            mainWindow.setScenarioPlayCount(adaptID, gameID, scenarioID, scenarioNewPlayCount);
            mainWindow.setScenarioKFct(adaptID, gameID, scenarioID, scenarioNewKFct);
            mainWindow.setScenarioUncertainty(adaptID, gameID, scenarioID, scenarioNewUncertainty);
            mainWindow.setScenarioLastPlayed(adaptID, gameID, scenarioID, currDateTimeStr);

            // [SC] creating game log
            mainWindow.createNewRecord(adaptID, gameID, playerID, scenarioID, rt, correctAnswer, playerNewRating, scenarioNewRating, currDateTimeStr);
        }

        // [TODO] needs more work after prototype
        public string getTargetScenarioID(string adaptID, string gameID, string playerID) {
            // [SC] get player rating
            string playerRatingStr = mainWindow.getPlayerRating(adaptID, gameID, playerID);
            if (playerRatingStr == null)
                throw new System.ArgumentException("Unable to get rating for player " + playerID + " for adaptation " + adaptID + " in game " + gameID);
            double playerRating = Double.Parse(playerRatingStr);

            // [SC] get IDs of available scenarios
            ObservableCollection<string> scenarioIDList = mainWindow.getAllScenarios(adaptID, gameID);
            if (scenarioIDList.Count == 0)
                throw new System.ArgumentException("No scenarios found for adaptation " + adaptID + " in game " + gameID);

            double targetScenarioRating = getTargetBeta(playerRating);
            double minDistance = 0;
            string minDistanceScenarioID = null;
            double minPlayCount = 0;

            foreach (string scenarioID in scenarioIDList) {
                if (scenarioID == null)
                    throw new System.ArgumentException("Null scenario ID found for adaptation " + adaptID + " in game " + gameID);

                string scenarioPlayCountStr = mainWindow.getScenarioPlayCount(adaptID, gameID, scenarioID);
                string scenarioRatingStr = mainWindow.getScenarioRating(adaptID, gameID, scenarioID);

                if (scenarioRatingStr == null || scenarioPlayCountStr == null)
                    throw new System.ArgumentException("Unable to get data on scenario " + scenarioID + " for adaptation " + adaptID + " in game " + gameID);

                double scenarioRating = Double.Parse(scenarioRatingStr);
                double scenarioPlayCount = Double.Parse(scenarioPlayCountStr);

                double distance = Math.Abs(scenarioRating - targetScenarioRating);
                if (minDistanceScenarioID == null || distance < minDistance) {
                    minDistance = distance;
                    minDistanceScenarioID = scenarioID;
                    minPlayCount = scenarioPlayCount;
                }
                else if (distance == minDistance && scenarioPlayCount < minPlayCount) {
                    minDistance = distance;
                    minDistanceScenarioID = scenarioID;
                    minPlayCount = scenarioPlayCount;
                }
            }

            return minDistanceScenarioID;
        }


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: functions for calculating target beta rating

        private double getTargetBeta(double theta) {
            double randomNum;
            do {
                randomNum = SimpleRNG.GetNormal(TARGET_DISTR_MEAN, TARGET_DISTR_SD);
            } while (randomNum <= TARGET_LOWER_LIMIT || randomNum >= TARGET_UPPER_LIMIT);
            return theta + Math.Log(randomNum / (1 - randomNum));
        }

        ////// END: functions for calculating target beta rating
        //////////////////////////////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: functions for calculating expected and actual scores

        /// <summary>
        /// [SC] Calculates actual score given sucess/failure outcome and response time
        /// </summary>
        /// <param name="correctAnswerFlag">should be either 0, for failure, or 1 for success</param>
        /// <param name="responseTime">a response time in milliseconds</param>
        /// <param name="itemMaxDuration">maximum duration of time given to a player to provide an answer</param>
        /// <returns>actual score as a double</returns>
        private double calcActualScore(double correctAnswer, double responseTime, double itemMaxDuration) {
            validateResponseTime(responseTime);
            validateItemMaxDuration(itemMaxDuration);

            double discrParam = getDiscriminationParam(itemMaxDuration);
            return (double)(((2 * correctAnswer) - 1) * ((discrParam * itemMaxDuration) - (discrParam * responseTime)));
        }

        /// <summary>
        /// [SC] Calculates expected score given player's skill rating and item's difficulty rating.
        /// </summary>
        /// <param name="playerTheta">player's skill rating</param>
        /// <param name="itemBeta">item's difficulty rating</param>
        /// <param name="itemMaxDuration">maximum duration of time given to a player to provide an answer</param>
        /// <returns>expected score as a double</returns>
        private double calcExpectedScore(double playerTheta, double itemBeta, double itemMaxDuration) {
            validateItemMaxDuration(itemMaxDuration);

            double weight = getDiscriminationParam(itemMaxDuration) * itemMaxDuration;
            double expFctr = (double)Math.Exp(2.0 * weight * (playerTheta - itemBeta));

            return (weight * ((expFctr + 1.0) / (expFctr - 1.0))) - (1.0 / (playerTheta - itemBeta));
        }

        /// <summary>
        /// [SC] Calculates discrimination parameter a_i necessary to calculate expected and actual scores
        /// </summary>
        /// <param name="itemMaxDuration">maximum duration of time given to a player to provide an answer; should be player</param>
        /// <returns>discrimination parameter a_i as double number</returns>
        private double getDiscriminationParam(double itemMaxDuration) {
            return (double)(1.0 / itemMaxDuration);
        }

        ////// END: functions for calculating expected and actual scores
        //////////////////////////////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: functions for calculating rating uncertainties

        /// <summary>
        /// [SC] Calculates a new uncertainty for the theta rating
        /// </summary>
        /// <param name="currThetaU">current uncertainty value for theta rating</param>
        /// <param name="currDelayCount">the current number of consecutive days the player has not played</param>
        /// <returns>a new uncertainty value for theta rating</returns>
        private double calcThetaUncertainty(double currThetaU, double currDelayCount) {
            double newThetaU = currThetaU - (1.0 / maxPlay) + (currDelayCount / maxDelay);
            if (newThetaU < 0) newThetaU = 0.0;
            else if (newThetaU > 1) newThetaU = 1.0;
            return newThetaU;
        }

        /// <summary>
        /// [SC] Calculates a new uncertainty for the beta rating
        /// </summary>
        /// <param name="currBetaU">current uncertainty value for the beta rating</param>
        /// <param name="currDelayCount">the current number of consecutive days the item has not beein played</param>
        /// <returns>a new uncertainty value for the beta rating</returns>
        private double calcBetaUncertainty(double currBetaU, double currDelayCount) {
            double newBetaU = currBetaU - (1.0 / maxPlay) + (currDelayCount / maxDelay);
            if (newBetaU < 0) newBetaU = 0.0;
            else if (newBetaU > 1) newBetaU = 1.0;
            return newBetaU;
        }

        /// <summary>
        /// [SC] Getter/setter for the maxDelay variable
        /// </summary>
        public double MaxDelay {
            get { return maxDelay; }
            set {
                if (value <= 0) throw new System.ArgumentException("The maximum number of delay days should be higher than 0.");
                else maxDelay = value;
            }
        }

        /// <summary>
        /// [SC] Getter/setter for the maxPlay variable
        /// </summary>
        public double MaxPlay {
            get { return maxPlay; }
            set {
                if (value <= 0) throw new System.ArgumentException("The maximum administration parameter should be higher than 0.");
                else maxPlay = value;
            }
        }

        /// <summary>
        /// [SC] Getter/setter for the provisional uncertainty
        /// </summary>
        public double ProvU {
            get { return provU; }
            set {
                if (0 < value || value > 1) throw new System.ArgumentException("Provisional uncertainty value should be between 0 and 1");
                else provU = value;
            }
        }

        /// <summary>
        /// [SC] Getter for the provisional playdate
        /// </summary>
        public string ProvDate {
            get { return provDate; }
        }

        ////// END: functions for calculating rating uncertainties
        //////////////////////////////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: functions for calculating k factors

        /// <summary>
        /// [SC] Calculates a new K factor for theta rating
        /// </summary>
        /// <param name="currThetaU">current uncertainty for the theta rating</param>
        /// <param name="currBetaU">current uncertainty for the beta rating</param>
        /// <returns>a double value of a new K factor for the theta rating</returns>
        private double calcThetaKFctr(double currThetaU, double currBetaU) {
            return kConst * (1 + (kUp * currThetaU) - (kDown * currBetaU));
        }

        /// <summary>
        /// [SC] Calculates a new K factor for the beta rating
        /// </summary>
        /// <param name="currThetaU">current uncertainty fot the theta rating</param>
        /// <param name="currBetaU">current uncertainty for the beta rating</param>
        /// <returns>a double value of a new K factor for the beta rating</returns>
        private double calcBetaKFctr(double currThetaU, double currBetaU) {
            return kConst * (1 + (kUp * currBetaU) - (kDown * currThetaU));
        }

        /// <summary>
        /// [SC] Getter/setter for the downward uncertainty weight
        /// </summary>
        public double KDown {
            get { return kDown; }
            set {
                if (value < 0) throw new System.ArgumentException("The downward uncertainty weight cannot be a negative number.");
                else kDown = value;
            }
        }

        /// <summary>
        /// [SC] Getter/setter for the upward uncertainty weight
        /// </summary>
        public double KUp {
            get { return kUp; }
            set {
                if (value < 0) throw new System.ArgumentException("The upward uncertianty weight cannot be a negative number.");
                else kUp = value;
            }
        }

        /// <summary>
        /// [SC] Getter/setter for the K contant
        /// </summary>
        public double KConst {
            get { return kConst; }
            set {
                if (value < 0) throw new System.ArgumentException("K constant cannot be a negative number.");
                else kConst = value;
            }
        }

        ////// END: functions for calculating k factors
        //////////////////////////////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: functions for calculating theta and beta ratings

        /// <summary>
        /// [SC] Calculates a new theta rating
        /// </summary>
        /// <param name="currTheta">current theta rating</param>
        /// <param name="thetaKFctr">K factor for the theta rating</param>
        /// <param name="actualScore">actual performance score</param>
        /// <param name="expectScore">expected performance score</param>
        /// <returns>a double value for the new theta rating</returns>
        private double calcTheta(double currTheta, double thetaKFctr, double actualScore, double expectScore) {
            return currTheta + (thetaKFctr * (actualScore - expectScore));
        }

        /// <summary>
        /// [SC] Calculates a new beta rating
        /// </summary>
        /// <param name="currBeta">current beta rating</param>
        /// <param name="betaKFctr">K factor for the beta rating</param>
        /// <param name="actualScore">actual performance score</param>
        /// <param name="expectScore">expected performance score</param>
        /// <returns>a double value for new beta rating</returns>
        private double calcBeta(double currBeta, double betaKFctr, double actualScore, double expectScore) {
            return currBeta + (betaKFctr * (expectScore - actualScore));
        }

        ////// END: functions for calculating theta and beta ratings
        //////////////////////////////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////////////////////////////
        ////// START: tester fuctions

        //// [TODO][SC] what to do with expceptions: let the program crash?, or catch them?, or let to propagate to the main method? create a log file?

        /// <summary>
        /// Tests the validity of the value representing the response time.
        /// </summary>
        /// <param name="responseTime"></param>
        private void validateResponseTime(double responseTime) {
            if (responseTime == 0) throw new System.ArgumentException("Parameter cannot be 0.", "responseTime");
            if (responseTime < 0) throw new System.ArgumentException("Parameter cannot be negative.", "responseTime");
        }

        /// <summary>
        /// Tests the validity of the value representing the max amount of time to respond.
        /// </summary>
        /// <param name="itemMaxDuration"></param>
        private void validateItemMaxDuration(double itemMaxDuration) {
            if (itemMaxDuration == 0) throw new System.ArgumentException("Parameter cannot be 0.", "itemMaxDuration");
            if (itemMaxDuration < 0) throw new System.ArgumentException("Parameter cannot be negative.", "itemMaxDuration");
        }

        ////// START: tester fuctions
        //////////////////////////////////////////////////////////////////////////////////////

        public double ProvTheta {
            get { return DEF_THETA; }
        }
    }
}
