﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Game
Filename: Game.cs
Description:
    Implements the main logic of the Qwirkle game.
Disclaimer:
    Qwirkle is an intelectual property of and trademarked by MindWare, Inc (http://www.mindware.com/).
    The author of this source code does not claim intelectual property rights to Qwirkle.
    The game is used for non-comercial education purpose only.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading; // [SC] Thread 
using System.Windows.Threading; // [SC] Dispatcher
using System.Windows.Controls; // [SC] For using Image class.
using System.Diagnostics; // [SC] for debugging messages

using QwirkleAppNet35.Game.DataStructure;

namespace QwirkleAppNet35.Game 
{
    public class Game 
    {
        QwirkleGameWindow qwirkleWindow;

        private List<QwirkleTile> tileBag;

        private VirtualQwirkleBoard virtualBoard;
        private List<Player> players;
        private Player humanPlayer;

        private int activePlayerIndex;

        private int playabelTileCount;
        private int playedTileCount; // [SC] increments whenever a starting tile is put on a board or player receives a tile without dropping;

        private int selectedRowIndex;
        private int selectedColIndex;

        private double correctAnswer;

        private bool newGameInitFlag;
        private bool activeGameFlag;

        private bool startTurnFlag;
        private bool endTurnFlag;

        public Game(QwirkleGameWindow qwirkleWindow, VisualQwirkleBoard visualBoard, VisualControlPanel ctrlPanel) {
            virtualBoard = new VirtualQwirkleBoard(this);

            this.qwirkleWindow = qwirkleWindow;
        }

        public void initNewGame(string playerName, string[] aiID, bool giveHint, int playableTileCount) {
            int aiPlayerCount = aiID.Length;

            createTileBag();

            if (verifyPlayableTileCount(playableTileCount, aiPlayerCount)) this.playabelTileCount = playableTileCount;
            else this.playabelTileCount = tileBag.Count;

            playedTileCount = 0;

            virtualBoard.resetBoard();

            createPlayers(playerName, aiID, giveHint); // [SC] should be called after 3 tiles were put on a board

            activePlayerIndex = 0;

            correctAnswer = 0;

            newGameInitFlag = true;
        }

        public void startNewGame() {
            if (!newGameInitFlag) return;

            if (activeGameFlag) return;

            putStartingTiles();

            newGameInitFlag = false;
            activeGameFlag = true;

            startTurnFlag = true;
            endTurnFlag = false;

            while (activeGameFlag) {
                bool endGameFlag = false;

                if (startTurnFlag) {
                    startTurnFlag = false;
                    startTurn();
                }

                if (endTurnFlag) {
                    endTurnFlag = false;
                    endGameFlag = endTurn();
                }

                if(endGameFlag){
                    endGame();
                    break;
                }

                Thread.Sleep(100);
            }
        }

        public void endGame() {
            if (!activeGameFlag) return;

            Player activePlayer = players[activePlayerIndex];
            activePlayer.increaseScore(Cfg.LAST_PLAYER_REWARD);

            // [SC] update scores and tile buttons
            qwirkleWindow.updateControlPanel();

            int maxScore = Cfg.NONE;
            List<Player> maxScorePlayers = new List<Player>();
            foreach (Player player in players) {
                int playerScore = player.getPlayerScore();
                if (maxScore == Cfg.NONE || maxScore == playerScore) {
                    maxScorePlayers.Add(player);
                    maxScore = playerScore;
                }
                else if (maxScore < playerScore) {
                    maxScorePlayers.Clear();
                    maxScorePlayers.Add(player);
                    maxScore = playerScore;
                }
            }

            if (maxScorePlayers.Count > 1) {
                Cfg.showMsg("It is a draw!");
            }
            else {
                Cfg.showMsg(maxScorePlayers[0].getPlayerName() + " won the game!");

                if (maxScorePlayers[0] == humanPlayer) correctAnswer = 1;
            }

            activeGameFlag = false;

            // [SC] notify the asset about results of the game
            qwirkleWindow.endGameDelegate(correctAnswer);

            // [TODO] disable all the controls
        }

        public void forceEndGame() {
            activeGameFlag = false;
        }

        private void startTurn() {
            if (!activeGameFlag) return;

            Player activePlayer = players[activePlayerIndex];

            // [TODO] play beep music
            Cfg.showMsg(activePlayer.getPlayerName() + "'s turn.");

            // [SC] update scores and tile buttons
            qwirkleWindow.updateControlPanel();

            if (activePlayer.isHuman()) {
                activePlayer.getAIHint();
            }
            else {
                activePlayer.invokeAI();
                endTurn(activePlayerIndex);
            }
        }

        public void endTurn(int playerIndex) {
            if (!activeGameFlag) Cfg.showMsg("No active game.");
            else if (playerIndex != activePlayerIndex) Cfg.showMsg("Not your turn!" + playerIndex);
            else endTurnFlag = true;
        }

        private bool endTurn() {
            // [SC] reset board position
            resetSelected();

            Player activePlayer = players[activePlayerIndex];

            // [SC] reset player's variables that are persistent only for a turn
            activePlayer.resetTurnVars();

            // [SC] refill player's tile array with new tiles from bag
            fillPlayerTiles(activePlayer);

            // [SC] if player has no tiles then end the game
            if (activePlayer.getPlayerTileCount() == 0) return true;

            // [SC] make the next player in a queue as a current player
            if (++activePlayerIndex >= players.Count) activePlayerIndex = 0;

            // [SC] set a flag to start a next turn
            startTurnFlag = true;

            return false;
        }

        private void createTileBag() {
            tileBag = new List<QwirkleTile>();

            for (int colorIndex = 0; colorIndex < Cfg.MAX_VAL_INDEX; colorIndex++) {
                for (int shapeIndex = 0; shapeIndex < Cfg.MAX_VAL_INDEX; shapeIndex++) {
                    for (int tileID = 0; tileID < Cfg.MAX_TILE_ID; tileID++) {
                        tileBag.Add(new QwirkleTile(colorIndex, shapeIndex, tileID));
                    }
                }
            }

            tileBag.Shuffle();
        }

        private void putStartingTiles() {
            int startCol = virtualBoard.getColCount() / 2 - Cfg.START_TILE_COUNT / 2;
            int startRow = virtualBoard.getRowCount() / 2;

            for (int counter = 0; counter < Cfg.START_TILE_COUNT; counter++) {
                int currCol = startCol + counter;
                QwirkleTile tile = (QwirkleTile)tileBag.ElementAt(0);

                int result = putTileOnBoard(startRow, currCol, tile, false);

                // [TODO] need to terminate the game
                if (result == Cfg.NONE) {
                    Cfg.showMsg("Error putting starting tiles");
                    break;
                }

                tileBag.Remove(tile);
                ++playedTileCount;
            }
        }

        // [SC] a function for dropping a tile
        public void dropPlayerTile(int playerIndex) {
            if (!activeGameFlag) return;

            if (playerIndex != activePlayerIndex) {
                Cfg.showMsg("It is not your turn!");
                return;
            }

            Player activePlayer = players[activePlayerIndex];

            // [SC] check if player drop tiles
            if (!activePlayer.getCanDrop()) {
                Cfg.showMsg("Cannot drop a tile after putting a tile on a board!"); // [TODO]
                return;
            }

            // [SC] check if bag has tiles
            if (tileBag.Count == 0) {
                Cfg.showMsg("Cannot drop a tile! The bag is empty."); // [TODO]
                return;
            }

            // [SC] check if player tile is selected
            if (!activePlayer.isTileSelected()) {
                Cfg.showMsg("Select a tile at first!"); // [TODO]
                return;
            }

            QwirkleTile tile = activePlayer.getSelectedTile();

            // [SC] make sure that the tile being dropped is not a replacement tile of previously dropped tile
            if (!tile.getCanDrop()) {
                Cfg.showMsg("Cannot drop a replacement tile!");
                return;
            }

            foreach (QwirkleTile newTile in tileBag) {
                // [SC] make sure that the new tile does not have the same features as the dropped tile
                if (newTile.getColorIndex() == tile.getColorIndex() && newTile.getShapeIndex() == tile.getShapeIndex()) continue;

                // [SC] remove the dropped tile from player's stack
                activePlayer.removeTile(tile);
                // [SC] add the dropped tile into the bag
                tileBag.Add(tile);

                // [SC] remove the new tile from the bag 
                tileBag.Remove(newTile);
                // [SC] add the new tile to player's stack
                activePlayer.addTile(newTile);
                // [SC] make sure that the new tile cannot be dropped in the same turn
                newTile.setCanDrop(false);

                // [SC] shuffle the bag
                tileBag.Shuffle();

                // [SC] prevent the player from moving tiles into the board
                activePlayer.setCanMove(false);

                // [SC] update scores and tile buttons
                qwirkleWindow.updateControlPanel();

                break;
            }
        }

        // [SC] place active player's tile on a board
        public void placePlayerTileOnBoard(int playerIndex) {
            if (!activeGameFlag) return;

            if (playerIndex != activePlayerIndex) {
                Cfg.showMsg("It is not your turn!");
                return;
            }

            Player activePlayer = players[activePlayerIndex];

            // [SC] check if player can put tiles on a board
            if (!activePlayer.getCanMove()) {
                Cfg.showMsg("Cannot move a tile after dropping a tile!"); // [TODO]
                return;
            }

            // [SC] check if board position is selected
            if (!isSelected()) {
                Cfg.showMsg("Select a board position at first!"); // [TODO]
                return;
            }

            // [SC] check if player tile is selected
            if (!activePlayer.isTileSelected()) {
                Cfg.showMsg("Select a tile at first!"); // [TODO]
                return;
            }

            QwirkleTile tile = activePlayer.getSelectedTile();
            int result = putTileOnBoard(selectedRowIndex, selectedColIndex, tile, true);
            if (result != Cfg.NONE) {
                // [SC] increase player's score
                activePlayer.increaseScore(result);

                // [SC] remove the tile from the player and reset player selection
                activePlayer.removeSelectedTile();

                // [SC] disable mismatching tiles
                activePlayer.disableMismatchedTiles(tile.getColorIndex(), tile.getShapeIndex());

                // [SC] prevent the player from dropping tiles in the same turn
                activePlayer.setCanDrop(false);

                // [SC] reset board selection
                resetSelected();

                // [SC] update scores and tile buttons
                qwirkleWindow.updateControlPanel();
            }
        }

        // [SC] put a given tile on a specified board position; validCheck is true then verify if the move conforms to game rules
        private int putTileOnBoard(int rowIndex, int colIndex, QwirkleTile tile, bool validCheck) {
            int result = virtualBoard.addTile(rowIndex, colIndex, tile, validCheck, null);
            if (result != Cfg.NONE) {
                addVisualTile(rowIndex, colIndex, tile); // [SC] update visual board
                //tile.setRowColIndices(rowIndex, colIndex); // [TODO] delete if not necessary
            }
            return result;
        }

        private void createPlayers(string playerName, string[] aiID, bool giveHint) {
            players = new List<Player>();

            // [SC] creating a human player
            Player humanPlayer = new Player(0, Cfg.HUMAN_PLAYER, giveHint, this);
            humanPlayer.setPlayerName(playerName);
            this.humanPlayer = humanPlayer;
            fillPlayerTiles(humanPlayer);
            players.Add(humanPlayer);

            // [SC] creating AI players
            for (int currPlayerIndex = 0; currPlayerIndex < aiID.Length; currPlayerIndex++) {
                Player currPlayer = new Player(currPlayerIndex + 1, aiID[currPlayerIndex], false, this);
                fillPlayerTiles(currPlayer);
                players.Add(currPlayer);
            }
        }

        private void fillPlayerTiles(Player player) {
            // [SC] make sure the tile bag is not empty and not all playable tiles are used
            while (tileBag.Count > 0 && playedTileCount < playabelTileCount) {
                QwirkleTile tile = tileBag.ElementAt(0);
                if (player.addTile(tile)) {
                    tileBag.Remove(tile);
                    ++playedTileCount;
                }
                else {
                    break;
                }
            }
        }

        // [TODO] end the game
        private bool verifyPlayableTileCount(int tileCount, int aiPlayerCount) {
            int minTileCount = Cfg.START_TILE_COUNT + (aiPlayerCount + 1) * Cfg.MAX_PLAYER_TILE_COUNT;
            if (tileCount < minTileCount) {
                Cfg.showMsg("The minimum umber of playable tiles should be " + minTileCount + ". Using default bag size.");
                return false;
            }
            return true;
        }

        /////////////////////////////////////////////////////////////////
        ////// START: board cell selection

        public bool setSelectedCell(int rowIndex, int colIndex, int playerIndex) {
            if (playerIndex >= players.Count) {
                Cfg.showMsg("Unknown player with an index " + playerIndex + "."); //[TODO]
            }
            else if (activePlayerIndex != playerIndex) {
                Cfg.showMsg("It is not your turn, " + players[playerIndex].getPlayerName() + "!"); //[TODO]
            }
            else {
                selectedRowIndex = rowIndex;
                selectedColIndex = colIndex;
                return true;
            }

            return false;
        }

        public void resetSelected() {
            selectedRowIndex = Cfg.NONE;
            selectedColIndex = Cfg.NONE;
        }

        // [SC] returns true if any board cell is selected
        public bool isSelected() {
            if (selectedRowIndex != Cfg.NONE && selectedColIndex != Cfg.NONE) return true;
            return false;
        }

        ////// END: board cell selection
        /////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////

        // [SC] called by the QwirkleGameWindow
        public int getBoardRowCount() {
            if (virtualBoard != null) return virtualBoard.getRowCount();
            else return 0;
        }

        // [SC] called by the QwirkleGameWindow
        public int getBoardColCount() {
            if (virtualBoard != null) return virtualBoard.getColCount();
            else return 0;
        }

        /////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////
        ////// START: interfaces to/for QwirkleGameWindow <=> VisualControlPanel

        // [SC] interface for QwirkleGameWindow
        public string getPlayerNameByIndex(int playerIndex) {
            return players[playerIndex].getPlayerName();
        }

        // [SC] interface for QwirkleGameWindow
        public int getPlayerScoreByIndex(int playerIndex) {
            return players[playerIndex].getPlayerScore();
        }

        // [SC] interface for QwirkleGameWindow
        public AbstractTile getHumanPlayerTileByIndex(int tileIndex) {
            QwirkleTile tile = humanPlayer.getTileAt(tileIndex);

            if (tile != null) return new AbstractTile(tile.getColorIndex(), tile.getShapeIndex(), tile.getTileID(), tile.getPlayable());
            else return null;
        }

        // [SC] interface for QwirkleGameWindow
        public void setSelectedPlayerTile(int colorIndex, int shapeIndex, int tileID) {
            // [SC] check if it is human player's turn
            if (activePlayerIndex != humanPlayer.getPlayerIndex()) {
                Cfg.showMsg("It is not your turn, " + humanPlayer.getPlayerName() + "!"); //[TODO]
                return;
            }

            // [TODO] what if parameters values are Cfg.NONE
            if (!humanPlayer.setSelectedTile(colorIndex, shapeIndex, tileID)) {
                Cfg.showMsg("The tile is not playable!");
            }
        }

        // [SC] interface for QwirkleGameWindow
        public void placeHumanPlayerTileOnBoard() {
            placePlayerTileOnBoard(humanPlayer.getPlayerIndex());
        }

        // [SC] interface for QwirkleGameWindow
        public void dropHumanPlayerTile() {
            dropPlayerTile(humanPlayer.getPlayerIndex());
        }

        // [SC] interface for QwirkleGameWindow
        public void endHumanPlayerTurn() {
            endTurn(humanPlayer.getPlayerIndex());
        }

        ////// END: interfaces to/for QwirkleGameWindow <=> VisualControlPanel
        /////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////
        ////// START: interfaces to/for QwirkleGameWindow <=> VisualQwirkleBoard

        // [SC] calls to QwirkleGameWindow => VisualQwirkleBoard interfaces
        private void addVisualTile(int rowIndex, int colIndex, QwirkleTile tile) {
            qwirkleWindow.addTile(rowIndex, colIndex, tile.getColorIndex(), tile.getShapeIndex());
        }

        // [SC] interface for QwirkleGameWindow <= VisualQwirkleBoard
        public void setSelectedCell(int rowIndex, int colIndex) {
            setSelectedCell(rowIndex, colIndex, humanPlayer.getPlayerIndex());
        }

        ////// END: interfaces to/for QwirkleGameWindow <=> VisualQwirkleBoard
        /////////////////////////////////////////////////////////////////

        // [SC] called by Player
        public VirtualQwirkleBoard getVirtualBoard() {
            return virtualBoard;
        }



        // [TEST]
        /*public void startNewGame(string playerName, int aiPlayerCount, int aiLevel, bool giveHint, int playableTileCount) {
            Debug.WriteLine("Here");

            Player currPlayer = new Player(0, false, false, aiLevel, this);

            virtualBoard.addTile(7, 6, new QwirkleTile(3, 1, 6), false, null);
            virtualBoard.addTile(7, 7, new QwirkleTile(2, 1, 7), false, null);
            virtualBoard.addTile(7, 8, new QwirkleTile(4, 2, 8), false, null);
            virtualBoard.addTile(8, 7, new QwirkleTile(2, 0, 9), false, null);
            virtualBoard.addTile(9, 7, new QwirkleTile(2, 3, 10), false, null);
            virtualBoard.addTile(9, 8, new QwirkleTile(2, 0, 11), false, null);

            currPlayer.addTile(new QwirkleTile(5, 4, 0));
            currPlayer.addTile(new QwirkleTile(0, 3, 1));
            currPlayer.addTile(new QwirkleTile(1, 3, 2));
            currPlayer.addTile(new QwirkleTile(1, 0, 3));
            currPlayer.addTile(new QwirkleTile(3, 1, 4));
            currPlayer.addTile(new QwirkleTile(5, 3, 5));

            if(false){
            virtualBoard.addTile(7, 6, new QwirkleTile(1, 1, 6), false, null);
            virtualBoard.addTile(7, 7, new QwirkleTile(1, 1, 7), false, null);
            virtualBoard.addTile(7, 8, new QwirkleTile(1, 1, 8), false, null);
            virtualBoard.addTile(8, 7, new QwirkleTile(2, 1, 9), false, null);
            virtualBoard.addTile(9, 7, new QwirkleTile(1, 1, 10), false, null);
            virtualBoard.addTile(9, 8, new QwirkleTile(1, 1, 11), false, null);

            currPlayer.addTile(new QwirkleTile(2, 2, 0));
            currPlayer.addTile(new QwirkleTile(2, 2, 1));

            currPlayer.calculateMoves();
            }
        }*/
    }
}
