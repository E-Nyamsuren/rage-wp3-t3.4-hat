﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Game
Filename: QwirkleGameWindow.cs
Description:
    Implements the main visual window for the Qwirkle game's view component.
Disclaimer:
    Qwirkle is an intelectual property of and trademarked by MindWare, Inc (http://www.mindware.com/).
    The author of this source code does not claim intelectual property rights to Qwirkle.
    The game is used for non-comercial education purpose only.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading; // Thread
using System.Windows.Threading; // Dispatcher
using System.Windows; // Window
using System.Windows.Controls; // DockPanel, Border
using System.Diagnostics; // Stopwatch
using System.ComponentModel; // CancelEventArgs

using QwirkleAppNet35.Game.DataStructure;

namespace QwirkleAppNet35.Game 
{
    public partial class QwirkleGameWindow : Window 
    {
        private MainWindow mainWindow;

        private VisualQwirkleBoard visualBoard;
        private VisualControlPanel ctrlPanel;
        private Game myGame;
        private Stopwatch sw;
        private Thread workerThread;

        private bool initizliedFlag = false;

        private string adaptID;
        private string playerID;
        private string aiID;
        private bool activeGameFlag;

        public QwirkleGameWindow(MainWindow mainWindow) {
            Title = "Qwirkle";

            this.mainWindow = mainWindow;

            init();

            Show();
        }

        private void init() {
            initResources();

            initUI();

            Closing += doClosingStuff;

            initizliedFlag = true;

            activeGameFlag = false;
        }

        private void initResources() {
            sw = new Stopwatch();

            visualBoard = new VisualQwirkleBoard(this);
            ctrlPanel = new VisualControlPanel(this);

            myGame = new Game(this, visualBoard, ctrlPanel);
        }

        private void initUI() {
            DockPanel mainDockPanel = new DockPanel();
            mainDockPanel.LastChildFill = true;

            /////////////////////////////////////////////////////////////////

            Border boardBorder = new Border();
            DockPanel.SetDock(boardBorder, Dock.Left);
            //boardBorder.Background = Brushes.SeaGreen;

            boardBorder.Width = visualBoard.Width;
            boardBorder.Height = visualBoard.Height;

            boardBorder.Child = visualBoard;
            mainDockPanel.Children.Add(boardBorder);

            /////////////////////////////////////////////////////////////////

            Border controlBorder = new Border();
            DockPanel.SetDock(controlBorder, Dock.Right);
            //controlBorder.Background = Brushes.SkyBlue;

            controlBorder.Width = Cfg.SIDE_PANEL_WIDTH;
            controlBorder.Height = visualBoard.Height;

            controlBorder.Child = ctrlPanel;
            mainDockPanel.Children.Add(controlBorder);

            /////////////////////////////////////////////////////////////////

            mainDockPanel.Width = boardBorder.Width + controlBorder.Width;
            mainDockPanel.Height = boardBorder.Height;

            this.Content = mainDockPanel;

            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        public void startNewGame(string adaptID, string playerID) {
            if (activeGameFlag) {
                Cfg.showMsg("Another game is already running.");
                return;
            }

            if (!initizliedFlag) {
                Cfg.showMsg("The game was not initialized.");
                return;
            }

            if (adaptID == null || playerID == null) {
                Cfg.showMsg("Null player or adaptation ID.");
                return;
            }

            string aiID = mainWindow.getTargetScenarioID(adaptID, Cfg.GAME_ID, playerID);
            string[] aiIDArray;
            if (aiID == null) aiIDArray = new string[] { Cfg.MEDIUM_COLOR_AI }; // [SC] if no AI ID was provided then use default one
            else aiIDArray = new string[] { aiID };

            this.adaptID = adaptID;
            this.playerID = playerID;
            this.aiID = aiID;

            // [SC] check if stopwatch is running
            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            // [SC] initialize game logic
            myGame.initNewGame(playerID, aiIDArray, false, 30);

            // [SC] initialize visual board
            visualBoard.initBoard(myGame.getBoardRowCount(), myGame.getBoardColCount());
            visualBoard.resetBoard();

            // [SC] initialize control panel
            ctrlPanel.initPanel(Cfg.MAX_PLAYER_TILE_COUNT, 1 + aiIDArray.Length);
            updateControlPanel();

            workerThread = new Thread(myGame.startNewGame);
            workerThread.IsBackground = true;
            activeGameFlag = true;
            sw.Start();
            workerThread.Start();
        }

        public void endGameDelegate(double correctAnswer) {
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() => {
                // [SC] notify the asset about results of the game
                this.endGame(correctAnswer);
            }));
        }

        // [SC] called by Game
        public void endGame(double correctAnswer) {
            activeGameFlag = false;
            sw.Stop();
            double rt = sw.ElapsedMilliseconds;
            sw.Reset();

            mainWindow.updateRatings(adaptID, Cfg.GAME_ID, playerID, aiID, rt, correctAnswer);

            if (workerThread != null) {
                if (workerThread.ThreadState == System.Threading.ThreadState.Running) {
                    myGame.forceEndGame();
                    workerThread.Join();
                }
                //while (workerThread.ThreadState != System.Threading.ThreadState.Stopped) ; // [SC]
            }
        }

        // [SC] called by VisualControlPanel
        public void restartGame() {
            startNewGame(adaptID, playerID);
        }

        private void doClosingStuff(object sender, CancelEventArgs e) {
            if (workerThread != null) {
                if (workerThread.ThreadState == System.Threading.ThreadState.Running) {
                    myGame.forceEndGame();
                    workerThread.Join();
                }
                //while (workerThread.ThreadState != System.Threading.ThreadState.Stopped) ; // [SC]
            }

            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            mainWindow.Show();
        }

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: called by VisualControlPanel

        public void updateControlPanel() {
            // [SC] update scores and tile buttons
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                ctrlPanel.updateScorePanel();
                ctrlPanel.updateTilePanel();
            }));
        }

        // [SC] intermediate interface for VisualControlPanel
        public string getPlayerNameByIndex(int playerIndex) {
            return myGame.getPlayerNameByIndex(playerIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public int getPlayerScoreByIndex(int playerIndex) {
            return myGame.getPlayerScoreByIndex(playerIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public AbstractTile getHumanPlayerTileByIndex(int tileIndex) {
            return myGame.getHumanPlayerTileByIndex(tileIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public void setSelectedPlayerTile(int colorIndex, int shapeIndex, int tileID) {
            myGame.setSelectedPlayerTile(colorIndex, shapeIndex, tileID);
        }

        // [SC] intermediate interface for VisualControlPanel
        public void placeHumanPlayerTileOnBoard() {
            myGame.placeHumanPlayerTileOnBoard();
        }

        // [SC] intermediate interface for VisualControlPanel
        public void dropHumanPlayerTile() {
            myGame.dropHumanPlayerTile();
        }

        // [SC] intermediate interface for VisualControlPanel
        public void endHumanPlayerTurn() {
            myGame.endHumanPlayerTurn();
        }

        ////// END: called by VisualControlPanel
        ////////////////////////////////////////////////////////////////////////////////////

        // [SC] interface for VisualQwirkleBoard
        public void setSelectedCell(int rowIndex, int colIndex) {
            myGame.setSelectedCell(rowIndex, colIndex);
        }

        public void addTile(int rowIndex, int colIndex, int colorIndex, int shapeIndex) {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                visualBoard.addTile(rowIndex, colIndex, colorIndex, shapeIndex);
            }));
        }
    }
}
