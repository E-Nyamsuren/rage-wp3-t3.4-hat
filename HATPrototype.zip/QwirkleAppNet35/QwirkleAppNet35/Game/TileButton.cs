﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: QwirkleAppNet35.Game
Filename: TileButton.cs
Description:
    Defines a class that represents a Qwirkle tile as a clickable button to be used in visual board or in human player's tile stack.
Disclaimer:
    Qwirkle is an intelectual property of and trademarked by MindWare, Inc (http://www.mindware.com/).
    The author of this source code does not claim intelectual property rights to Qwirkle.
    The game is used for non-comercial education purpose only.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // Button

namespace QwirkleAppNet35.Game 
{
    public class TileButton : Button 
    {
        private int rowIndex;
        private int colIndex;
        private int location;
        private string buttonID;

        private int colorIndex;
        private int shapeIndex;
        private int tileID;

        //[TODO]
        //private Object selectedBorder;
        //private Object defaultBorder;

        public TileButton(int rowIndex, int colIndex, int location, int colorIndex, int shapeIndex, int tileID)
            : base() {
            this.rowIndex = rowIndex;
            this.colIndex = colIndex;
            this.location = location;
            buttonID = createButtonID(rowIndex, colIndex, location);

            this.colorIndex = colorIndex;
            this.shapeIndex = shapeIndex;
            this.tileID = tileID;

            //this.Name = "";
            //this.Content = "";

            //this.Opacity = 0; // [SC] to make the buttons invisible

            //this.Background = Brushes.Transparent;
            //this.Foreground = Brushes.Transparent;
            //this.BorderBrush = Brushes.Transparent;
            //this.BorderThickness = new System.Windows.Thickness(0);
            //this.FocusVisualStyle = null;   

            //reset();
        }

        public TileButton(int rowIndex, int colIndex, int location)
            : this(rowIndex, colIndex, location, Cfg.NONE, Cfg.NONE, Cfg.NONE) { }

        public void addTileImage(Image tileImage, int colorIndex, int shapeIndex, int tileID, bool enabled) {
            this.Content = tileImage;
            this.colorIndex = colorIndex;
            this.shapeIndex = shapeIndex;
            this.tileID = tileID;
            this.IsEnabled = enabled;
        }

        public void addTileImage(Image tileImage, bool enabled) {
            addTileImage(tileImage, Cfg.NONE, Cfg.NONE, Cfg.NONE, enabled);
        }

        public void removeTileImage(bool enabled) {
            this.Content = null;
            this.colorIndex = Cfg.NONE;
            this.shapeIndex = Cfg.NONE;
            this.tileID = Cfg.NONE;
            this.IsEnabled = enabled;
        }

        public int getRowIndex() {
            return rowIndex;
        }

        public int getColIndex() {
            return colIndex;
        }

        public string getButtonID() {
            return buttonID;
        }

        public static string createButtonID(int rowIndexP, int colIndexP, int location) {
            return rowIndexP + "_" + colIndexP + "_" + location;
        }

        public int getColorIndex() {
            return colorIndex;
        }

        public int getShapeIndex() {
            return shapeIndex;
        }

        public int getTileID() {
            return tileID;
        }
    }
}
