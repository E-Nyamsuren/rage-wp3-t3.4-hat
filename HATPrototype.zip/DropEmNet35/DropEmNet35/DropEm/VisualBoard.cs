﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm
Filename: VisualBoard.cs
Description:
    It is a visual implementation of a DropEm board. Belongs to the View component.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows;
using System.Windows.Media; // for using Brushes
using System.Windows.Media.Imaging; // BitmapImage
using System.Windows.Controls; // [SC] For using Grid class.
using System.Diagnostics; // [SC] for debugging messages

namespace DropEmNet35.DropEm 
{
    public partial class VisualBoard : Grid 
    {
        private DropEmGameWindow gameWindow;

        private int rowCount;
        private int colCount;

        private const int cellSize = Cfg.TILE_SIZE; // the pixel size of a square cell's side

        private TileButton[,] buttonArray;

        public VisualBoard(DropEmGameWindow gameWindow)
            : base() {
            this.gameWindow = gameWindow;
        }

        public void initBoard(int rowCount, int colCount) {
            this.rowCount = rowCount;
            this.colCount = colCount;

            this.Width = colCount * cellSize;
            this.Height = rowCount * cellSize;

            this.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            this.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            this.ShowGridLines = false;

            this.Children.Clear();
            this.ColumnDefinitions.Clear();
            this.RowDefinitions.Clear();

            // [TODO][SC] there should be a better way to define columns and columns without manual for loops
            defineRowsColumns();

            addButtons();
        }

        public void resetBoard() {
            for (int currRowIndex = 0; currRowIndex < rowCount; currRowIndex++) {
                for (int currColIndex = 0; currColIndex < colCount; currColIndex++) {
                    buttonArray[currRowIndex, currColIndex].removeTileImage(true);
                }
            }
        }

        private void defineRowsColumns() {
            for (int currColIndex = 0; currColIndex < colCount; currColIndex++) {
                ColumnDefinition colDef = new ColumnDefinition();
                this.ColumnDefinitions.Add(colDef);
            }

            for (int currRowIndex = 0; currRowIndex < rowCount; currRowIndex++) {
                RowDefinition rowDef = new RowDefinition();
                this.RowDefinitions.Add(rowDef);
            }
        }

        private void addButtons() {
            buttonArray = new TileButton[rowCount, colCount];

            for (int currRowIndex = 0; currRowIndex < rowCount; currRowIndex++) {
                for (int currColIndex = 0; currColIndex < colCount; currColIndex++) {
                    TileButton cellButton = new TileButton(currRowIndex, currColIndex, Cfg.LOC_BOARD);
                    cellButton.Click += new RoutedEventHandler(cellButtonClick);

                    Grid.SetRow(cellButton, currRowIndex);
                    Grid.SetColumn(cellButton, currColIndex);
                    this.Children.Add(cellButton);

                    buttonArray[currRowIndex, currColIndex] = cellButton;
                }
            }
        }

        private void cellButtonClick(object sender, RoutedEventArgs e) {
            TileButton cellButton = (TileButton)sender;
            if (gameWindow != null) gameWindow.setSelectedCell(cellButton.getRowIndex(), cellButton.getColIndex());

            Debug.WriteLine("Event detected. Source is " + cellButton.getButtonID());
        }

        public void addTile(int rowIndex, int colIndex, int colorIndex, int shapeIndex) {
            TileButton cellButton = buttonArray[rowIndex, colIndex];
            cellButton.addTileImage(Cfg.getTileImage(colorIndex, shapeIndex), false);
        }

        public int getColCount() {
            return colCount;
        }

        public void setColCount(int colCount) {
            this.colCount = colCount;
        }

        public int getRowCount() {
            return rowCount;
        }

        public void setRowCount(int rowCount) {
            this.rowCount = rowCount;
        }

        public int getCellSize() {
            return cellSize;
        }
    }
}
