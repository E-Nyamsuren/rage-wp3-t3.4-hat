﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm
Filename: VisualControlPanel.cs
Description:
    Implements a visual control panel used by a human player. Shows players scores and provides control buttons such as end turn, place tile buttons.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Media; // Brushes
using System.Windows.Controls; // StackPanel
using System.Windows; // Thickness
using System.Diagnostics; // [SC] for debugging messages

using DropEmNet35.DropEm.DataStructure;

namespace DropEmNet35.DropEm 
{
    public class VisualControlPanel : StackPanel 
    {
        private DropEmGameWindow gameWindow;

        private StackPanel scorePanel;
        private StackPanel tilePanel;
        private StackPanel buttonPanel;

        private List<Label> playerLabels;
        private int playerCount;

        private List<TileButton> playerButtons;
        private int tileBtnCount;
        private TileButton selectedButton; //[SC] last clicked tile button //[TODO] remove if not necessary

        private Button placeBtn;
        private Button dropBtn;
        private Button endTurnBtn;
        private Button newGameBtn;

        public VisualControlPanel(DropEmGameWindow gameWindow)
            : base() {
            this.gameWindow = gameWindow;
        }

        // [SC] an interface for the Game
        public void initPanel(int tileBtnCount, int playerCount) {
            this.playerCount = playerCount;
            this.tileBtnCount = tileBtnCount;

            this.Orientation = Orientation.Vertical;

            createScorePanel();
            createTilePanel();
            createButtonPanel();

            this.Children.Clear();
            this.Children.Add(scorePanel);
            this.Children.Add(tilePanel);
            this.Children.Add(buttonPanel);
        }

        private void createScorePanel() {
            scorePanel = new StackPanel();
            scorePanel.Orientation = Orientation.Vertical;
            scorePanel.Margin = new Thickness { Bottom = Cfg.SIDE_PANEL_BTM_MARGIN };
            //scorePanel.Background = Brushes.Aqua; //[SC][TEMP]

            playerLabels = new List<Label>();

            for (int currLabelIndex = 0; currLabelIndex < playerCount; currLabelIndex++) {
                Label label = new Label();
                label.Content = "Placeholder";
                playerLabels.Add(label);
                scorePanel.Children.Add(label);
            }
        }

        // [SC] an interface for the Game
        public void updateScorePanel() {
            for (int currPlayerIndex = 0; currPlayerIndex < playerCount; currPlayerIndex++) {
                string currPlayerName = gameWindow.getPlayerNameByIndex(currPlayerIndex);
                int currPlayerScore = gameWindow.getPlayerScoreByIndex(currPlayerIndex);

                playerLabels[currPlayerIndex].Content = currPlayerName + ": " + currPlayerScore;
            }
        }

        private void createTilePanel() {
            tilePanel = new StackPanel();
            tilePanel.Orientation = Orientation.Vertical;
            tilePanel.Margin = new Thickness { Bottom = Cfg.SIDE_PANEL_BTM_MARGIN };
            //tilePanel.Background = Brushes.Red; //[SC][TEMP]

            playerButtons = new List<TileButton>();

            int colIndex = 0;
            for (int currRowIndex = 0; currRowIndex < tileBtnCount; currRowIndex++) {
                TileButton tileButton = new TileButton(currRowIndex, colIndex, Cfg.LOC_PLAYER);
                tileButton.Margin = new Thickness { Bottom = Cfg.SIDE_ELEM_BTM_MARGIN };
                tileButton.Width = Cfg.TILE_SIZE;
                tileButton.Height = Cfg.TILE_SIZE;
                tilePanel.Children.Add(tileButton);

                playerButtons.Add(tileButton);
                tileButton.Click += new RoutedEventHandler(tileButtonClick);
            }
        }

        // [SC] an interface for the Game
        public void updateTilePanel() {
            for (int currTileBtnIndex = 0; currTileBtnIndex < tileBtnCount; currTileBtnIndex++) {
                AbstractTile aTile = gameWindow.getHumanPlayerTileByIndex(currTileBtnIndex);
                if (aTile != null)
                    playerButtons[currTileBtnIndex].addTileImage(Cfg.getTileImage(aTile.colorIndex, aTile.shapeIndex)
                                                                    , aTile.colorIndex, aTile.shapeIndex, aTile.tileID, true);
                else
                    playerButtons[currTileBtnIndex].removeTileImage(false);
            }
        }

        private void tileButtonClick(object sender, RoutedEventArgs e) {
            TileButton playerButton = (TileButton)sender;
            gameWindow.setSelectedPlayerTile(playerButton.getColorIndex(), playerButton.getShapeIndex(), playerButton.getTileID());
            selectedButton = playerButton;

            Debug.WriteLine("Event detected. Source is " + playerButton.getButtonID());
        }

        private void createButtonPanel() {
            buttonPanel = new StackPanel();
            buttonPanel.Orientation = Orientation.Vertical;
            buttonPanel.Margin = new Thickness { Bottom = Cfg.SIDE_PANEL_BTM_MARGIN };
            //buttonPanel.Background = Brushes.Chocolate; //[SC][TEMP]

            placeBtn = new Button() { Width = Cfg.CTRL_BTN_WIDTH, Height = Cfg.CTRL_BTN_HEIGHT };
            placeBtn.Name = Cfg.PLACE_BTN_NAME;
            placeBtn.Content = Cfg.loadPlaceBtnImage();
            placeBtn.Margin = new Thickness { Bottom = Cfg.SIDE_ELEM_BTM_MARGIN };
            placeBtn.Click += new RoutedEventHandler(controlButtonClick);

            dropBtn = new Button() { Width = Cfg.CTRL_BTN_WIDTH, Height = Cfg.CTRL_BTN_HEIGHT };
            dropBtn.Name = Cfg.DROP_BTN_NAME;
            dropBtn.Content = Cfg.loadDropBtnImage();
            dropBtn.Margin = new Thickness { Bottom = Cfg.SIDE_ELEM_BTM_MARGIN };
            dropBtn.Click += new RoutedEventHandler(controlButtonClick);

            endTurnBtn = new Button() { Width = Cfg.CTRL_BTN_WIDTH, Height = Cfg.CTRL_BTN_HEIGHT };
            endTurnBtn.Name = Cfg.TURN_BTN_NAME;
            endTurnBtn.Content = Cfg.loadEndTurnBtnImage();
            endTurnBtn.Margin = new Thickness { Bottom = Cfg.SIDE_ELEM_BTM_MARGIN };
            endTurnBtn.Click += new RoutedEventHandler(controlButtonClick);

            newGameBtn = new Button() { Width = Cfg.CTRL_BTN_WIDTH, Height = Cfg.CTRL_BTN_HEIGHT };
            newGameBtn.Name = Cfg.NEW_BTN_NAME;
            newGameBtn.Content = Cfg.loadNewGameBtnImage();
            newGameBtn.Margin = new Thickness { Bottom = Cfg.SIDE_ELEM_BTM_MARGIN };
            newGameBtn.Click += new RoutedEventHandler(controlButtonClick);

            buttonPanel.Children.Add(placeBtn);
            buttonPanel.Children.Add(dropBtn);
            buttonPanel.Children.Add(endTurnBtn);
            buttonPanel.Children.Add(newGameBtn);
        }

        private void controlButtonClick(object sender, RoutedEventArgs e) {
            Button controlButton = (Button)sender;

            if (controlButton.Name.Equals(Cfg.PLACE_BTN_NAME)) {
                gameWindow.placeHumanPlayerTileOnBoard();
            }
            else if (controlButton.Name.Equals(Cfg.DROP_BTN_NAME)) {
                gameWindow.dropHumanPlayerTile();
            }
            else if (controlButton.Name.Equals(Cfg.TURN_BTN_NAME)) {
                gameWindow.endHumanPlayerTurn();
            }
            else if (controlButton.Name.Equals(Cfg.NEW_BTN_NAME)) {
                gameWindow.restartGame();
            }
            else {
                Cfg.showMsg("UNKNOWN BUTTON!");
            }
        }
    }
}
