﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm
Filename: DropEmGameWindow.cs
Description:
    Implements the main visual window for the DropEm game's view component. 
    It is an abstract class to facilitate diferent variations of HAT-based adaptation.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Threading; // Thread
using System.Windows.Threading; // Dispatcher
using System.Windows; // Window
using System.Windows.Controls; // DockPanel, Border
using System.Diagnostics; // Stopwatch
using System.ComponentModel; // CancelEventArgs

using DropEmNet35.DropEm.DataStructure;

namespace DropEmNet35.DropEm 
{
    public abstract partial class DropEmGameWindow : Window 
    {
        protected MainWindow mainWindow;

        protected VisualBoard visualBoard;
        protected VisualControlPanel ctrlPanel;
        protected Game myGame;
        protected Stopwatch sw;
        protected Thread workerThread;

        protected bool initizliedFlag = false;

        protected string adaptID;
        protected string playerID;
        protected string aiID;
        protected bool activeGameFlag;

        public DropEmGameWindow(MainWindow mainWindow) {
            Title = "DropEm";

            this.mainWindow = mainWindow;

            init();

            Show();
        }

        protected void init() {
            initResources();

            initUI();

            Closing += doClosingStuff;

            initizliedFlag = true;

            activeGameFlag = false;
        }

        protected abstract void initResources();

        public abstract void startNewGame(string adaptID, string playerID);

        // [SC] called by Game
        public abstract void endGame(double correctAnswer);

        protected abstract void doClosingStuff(object sender, CancelEventArgs e);

        protected void initUI() {
            DockPanel mainDockPanel = new DockPanel();
            mainDockPanel.LastChildFill = true;

            /////////////////////////////////////////////////////////////////

            Border boardBorder = new Border();
            DockPanel.SetDock(boardBorder, Dock.Left);
            //boardBorder.Background = Brushes.SeaGreen;

            boardBorder.Width = visualBoard.Width;
            boardBorder.Height = visualBoard.Height;

            boardBorder.Child = visualBoard;
            mainDockPanel.Children.Add(boardBorder);

            /////////////////////////////////////////////////////////////////

            Border controlBorder = new Border();
            DockPanel.SetDock(controlBorder, Dock.Right);
            //controlBorder.Background = Brushes.SkyBlue;

            controlBorder.Width = Cfg.SIDE_PANEL_WIDTH;
            controlBorder.Height = visualBoard.Height;

            controlBorder.Child = ctrlPanel;
            mainDockPanel.Children.Add(controlBorder);

            /////////////////////////////////////////////////////////////////

            mainDockPanel.Width = boardBorder.Width + controlBorder.Width;
            mainDockPanel.Height = boardBorder.Height;

            this.Content = mainDockPanel;

            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        public void endGameDelegate(double correctAnswer) {
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() => {
                // [SC] notify the asset about results of the game
                this.endGame(correctAnswer);
            }));
        }

        // [SC] called by VisualControlPanel
        public void restartGame() {
            startNewGame(adaptID, playerID);
        }

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: called by VisualControlPanel

        public void updateControlPanel() {
            // [SC] update scores and tile buttons
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                ctrlPanel.updateScorePanel();
                ctrlPanel.updateTilePanel();
            }));
        }

        // [SC] intermediate interface for VisualControlPanel
        public string getPlayerNameByIndex(int playerIndex) {
            return myGame.getPlayerNameByIndex(playerIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public int getPlayerScoreByIndex(int playerIndex) {
            return myGame.getPlayerScoreByIndex(playerIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public AbstractTile getHumanPlayerTileByIndex(int tileIndex) {
            return myGame.getHumanPlayerTileByIndex(tileIndex);
        }

        // [SC] intermediate interface for VisualControlPanel
        public void setSelectedPlayerTile(int colorIndex, int shapeIndex, int tileID) {
            myGame.setSelectedPlayerTile(colorIndex, shapeIndex, tileID);
        }

        // [SC] intermediate interface for VisualControlPanel
        public void placeHumanPlayerTileOnBoard() {
            myGame.placeHumanPlayerTileOnBoard();
        }

        // [SC] intermediate interface for VisualControlPanel
        public void dropHumanPlayerTile() {
            myGame.dropHumanPlayerTile();
        }

        // [SC] intermediate interface for VisualControlPanel
        public void endHumanPlayerTurn() {
            myGame.endHumanPlayerTurn();
        }

        ////// END: called by VisualControlPanel
        ////////////////////////////////////////////////////////////////////////////////////

        // [SC] interface for VisualBoard
        public void setSelectedCell(int rowIndex, int colIndex) {
            myGame.setSelectedCell(rowIndex, colIndex);
        }

        public void addTile(int rowIndex, int colIndex, int colorIndex, int shapeIndex) {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                visualBoard.addTile(rowIndex, colIndex, colorIndex, shapeIndex);
            }));
        }
    }
}
