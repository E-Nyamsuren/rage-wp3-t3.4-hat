﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm.TurnBased
Filename: Game.cs
Description:
    Extends and implements the class DropEmNet35.DropEm.Game.
    The HAT-based adaptation uses turn-based scenarios (AI difficulty adaptation is done after human player's each turn during the same game session). 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;

namespace DropEmNet35.DropEm.TurnBased {
    public class Game : DropEmNet35.DropEm.Game
    {
        private Stopwatch turnSW; // [SC][2015.09.02][DAI]
        private int aiPlayerTurnScore; // [SC][2015.09.02][DAI]
        private int humanPlayerTurnScore; // [SC][2015.09.02][DAI]
        private Player aiPlayer; // [SC][2015.09.02][DAI]

        public Game(DropEmNet35.DropEm.TurnBased.DropEmGameWindow dropemWindow, VisualBoard visualBoard)
            : base(dropemWindow, visualBoard) {

            turnSW = new Stopwatch(); // [SC][2015.09.02][DAI]
        }

        public override void initNewGame(string playerName, string[] aiID, bool giveHint, int playableTileCount) {
            int aiPlayerCount = aiID.Length;

            createTileBag();

            if (verifyPlayableTileCount(playableTileCount, aiPlayerCount)) this.playabelTileCount = playableTileCount;
            else this.playabelTileCount = tileBag.Count;

            playedTileCount = 0;

            virtualBoard.resetBoard();

            createPlayers(playerName, aiID, giveHint); // [SC] should be called after 3 tiles were put on a board

            activePlayerIndex = 0;

            correctAnswer = 0;

            newGameInitFlag = true;

            ///////////////////////////////////////////////////////////
            ////// START: [SC][2015.09.02][DAI]

            if (turnSW.IsRunning) turnSW.Stop();
            turnSW.Reset();
            aiPlayerTurnScore = Cfg.NONE;
            humanPlayerTurnScore = Cfg.NONE;

            ////// START: [SC][2015.09.02][DAI]
            ///////////////////////////////////////////////////////////
        }

        protected override void startTurn() {
            if (!activeGameFlag) return;

            Player activePlayer = players[activePlayerIndex];

            // [SC] update scores and tile buttons
            dropemWindow.updateControlPanel();

            if (activePlayer.isHuman()) {
                activePlayer.getAIHint();

                ///////////////////////////////////////////////
                ///// START: [SC][2015.09.02][DAI]

                // [SC] start the stopwatch and reset human player's turn score
                turnSW.Start();
                humanPlayerTurnScore = 0;

                Cfg.showMsg(activePlayer.getPlayerName() + "'s turn.");

                ///// END: [SC][2015.09.02][DAI]
                ///////////////////////////////////////////////
            }
            else {

                ///////////////////////////////////////////////
                ///// START: [SC][2015.09.02][DAI]

                // [SC] reset AI player's turn score
                aiPlayerTurnScore = 0;

                // [SC] decide on a new player ID
                string aiPlayerID = ((DropEmNet35.DropEm.TurnBased.DropEmGameWindow)dropemWindow).getTurnAIID();

                // [SC] set new AI player ID
                activePlayer.setPlayerType(aiPlayerID);

                // [SC] update scores and tile buttons
                dropemWindow.updateControlPanel();

                Cfg.showMsg(activePlayer.getPlayerName() + "'s turn.");

                ///// END: [SC][2015.09.02][DAI]
                ///////////////////////////////////////////////

                activePlayer.invokeAI();
                endTurn(activePlayerIndex);
            }
        }

        protected override bool endTurn() {
            // [SC] reset board position
            resetSelected();

            Player activePlayer = players[activePlayerIndex];

            ///////////////////////////////////////////////
            ///// START: [SC][2015.09.02][DAI]

            // [SC] make sure that it is human player's turn
            if (activePlayer.isHuman()) {
                // [SC] stop the stopwatch
                turnSW.Stop();

                // [SC] get turn RT and then reset the stopwatch
                double turnRT = turnSW.ElapsedMilliseconds;
                turnSW.Reset();

                // [SC] make sure there was a preceding turn with AI player
                if (aiPlayerTurnScore != Cfg.NONE) {
                    // [SC] get human player's accuracy for the turn
                    double turnAccuracy = 1;

                    // [SC] if the AI player has a higher or equal overall score and scored more points in the last turn than the human player 
                    // then assume that human player lost in last two turns
                    //if (aiPlayer.getPlayerScore() >= humanPlayer.getPlayerScore() && aiPlayerTurnScore >= humanPlayerTurnScore) turnAccuracy = 0;
                    if (aiPlayerTurnScore >= humanPlayerTurnScore) turnAccuracy = 0;

                    // [SC] updating player and scenario ratings
                    ((DropEmNet35.DropEm.TurnBased.DropEmGameWindow)dropemWindow).endTurn(turnRT, turnAccuracy);
                }
            }
            else {
                // [TODO] nothing to do?
            }

            ///// END: [SC][2015.09.02][DAI]
            ///////////////////////////////////////////////


            // [SC] reset player's variables that are persistent only for a turn
            activePlayer.resetTurnVars();

            // [SC] refill player's tile array with new tiles from bag
            fillPlayerTiles(activePlayer);

            // [SC] if player has no tiles then end the game
            if (activePlayer.getPlayerTileCount() == 0) return true;

            // [SC] make the next player in a queue as a current player
            if (++activePlayerIndex >= players.Count) activePlayerIndex = 0;

            // [SC] set a flag to start a next turn
            startTurnFlag = true;

            return false;
        }

        // [SC] place active player's tile on a board
        public override void placePlayerTileOnBoard(int playerIndex) {
            if (!activeGameFlag) return;

            if (playerIndex != activePlayerIndex) {
                Cfg.showMsg("It is not your turn!");
                return;
            }

            Player activePlayer = players[activePlayerIndex];

            // [SC] check if player can put tiles on a board
            if (!activePlayer.getCanMove()) {
                Cfg.showMsg("Cannot move a tile after dropping a tile!"); // [TODO]
                return;
            }

            // [SC] check if board position is selected
            if (!isSelected()) {
                Cfg.showMsg("Select a board position at first!"); // [TODO]
                return;
            }

            // [SC] check if player tile is selected
            if (!activePlayer.isTileSelected()) {
                Cfg.showMsg("Select a tile at first!"); // [TODO]
                return;
            }

            DropEmTile tile = activePlayer.getSelectedTile();
            int result = putTileOnBoard(selectedRowIndex, selectedColIndex, tile, true);
            if (result != Cfg.NONE) {
                // [SC] increase player's score
                activePlayer.increaseScore(result);

                // [SC][2015.09.02][DAI] collecting AI and human player's total score for one turn
                if (activePlayer.isHuman()) humanPlayerTurnScore += result;
                else aiPlayerTurnScore += result;

                // [SC] remove the tile from the player and reset player selection
                activePlayer.removeSelectedTile();

                // [SC] disable mismatching tiles
                activePlayer.disableMismatchedTiles(tile.getColorIndex(), tile.getShapeIndex());

                // [SC] prevent the player from dropping tiles in the same turn
                activePlayer.setCanDrop(false);

                // [SC] reset board selection
                resetSelected();

                // [SC] update scores and tile buttons
                dropemWindow.updateControlPanel();
            }
        }

        protected override void createPlayers(string playerName, string[] aiID, bool giveHint) {
            players = new List<Player>();

            // [SC] creating a human player
            Player humanPlayer = new Player(0, Cfg.HUMAN_PLAYER, giveHint, this);
            humanPlayer.setPlayerName(playerName);
            this.humanPlayer = humanPlayer;
            fillPlayerTiles(humanPlayer);
            players.Add(humanPlayer);

            // [SC] creating AI players
            for (int currPlayerIndex = 0; currPlayerIndex < aiID.Length; currPlayerIndex++) {
                Player currPlayer = new Player(currPlayerIndex + 1, aiID[currPlayerIndex], false, this);
                fillPlayerTiles(currPlayer);
                players.Add(currPlayer);

                aiPlayer = currPlayer; // [SC][2015.09.02][DAI]
            }
        }
    }
}
