﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm.SessionBased
Filename: Game.cs
Description:
    Extends and implements the class DropEmNet35.DropEm.Game.
    The HAT-based adaptation uses an entire game session as a scenarios.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DropEmNet35.DropEm.SessionBased 
{
    public class Game : DropEmNet35.DropEm.Game 
    {
        public Game(DropEmNet35.DropEm.SessionBased.DropEmGameWindow dropemWindow, VisualBoard visualBoard) 
            : base(dropemWindow, visualBoard) {
        }

        public override void initNewGame(string playerName, string[] aiID, bool giveHint, int playableTileCount) {
            int aiPlayerCount = aiID.Length;

            createTileBag();

            if (verifyPlayableTileCount(playableTileCount, aiPlayerCount)) this.playabelTileCount = playableTileCount;
            else this.playabelTileCount = tileBag.Count;

            playedTileCount = 0;

            virtualBoard.resetBoard();

            createPlayers(playerName, aiID, giveHint); // [SC] should be called after 3 tiles were put on a board

            activePlayerIndex = 0;

            correctAnswer = 0;

            newGameInitFlag = true;
        }

        protected override void startTurn() {
            if (!activeGameFlag) return;

            Player activePlayer = players[activePlayerIndex];

            // [TODO] play beep music
            Cfg.showMsg(activePlayer.getPlayerName() + "'s turn.");

            // [SC] update scores and tile buttons
            dropemWindow.updateControlPanel();

            if (activePlayer.isHuman()) {
                activePlayer.getAIHint();
            }
            else {
                activePlayer.invokeAI();
                endTurn(activePlayerIndex);
            }
        }

        protected override bool endTurn() {
            // [SC] reset board position
            resetSelected();

            Player activePlayer = players[activePlayerIndex];

            // [SC] reset player's variables that are persistent only for a turn
            activePlayer.resetTurnVars();

            // [SC] refill player's tile array with new tiles from bag
            fillPlayerTiles(activePlayer);

            // [SC] if player has no tiles then end the game
            if (activePlayer.getPlayerTileCount() == 0) return true;

            // [SC] make the next player in a queue as a current player
            if (++activePlayerIndex >= players.Count) activePlayerIndex = 0;

            // [SC] set a flag to start a next turn
            startTurnFlag = true;

            return false;
        }

        // [SC] place active player's tile on a board
        public override void placePlayerTileOnBoard(int playerIndex) {
            if (!activeGameFlag) return;

            if (playerIndex != activePlayerIndex) {
                Cfg.showMsg("It is not your turn!");
                return;
            }

            Player activePlayer = players[activePlayerIndex];

            // [SC] check if player can put tiles on a board
            if (!activePlayer.getCanMove()) {
                Cfg.showMsg("Cannot move a tile after dropping a tile!"); // [TODO]
                return;
            }

            // [SC] check if board position is selected
            if (!isSelected()) {
                Cfg.showMsg("Select a board position at first!"); // [TODO]
                return;
            }

            // [SC] check if player tile is selected
            if (!activePlayer.isTileSelected()) {
                Cfg.showMsg("Select a tile at first!"); // [TODO]
                return;
            }

            DropEmTile tile = activePlayer.getSelectedTile();
            int result = putTileOnBoard(selectedRowIndex, selectedColIndex, tile, true);
            if (result != Cfg.NONE) {
                // [SC] increase player's score
                activePlayer.increaseScore(result);

                // [SC] remove the tile from the player and reset player selection
                activePlayer.removeSelectedTile();

                // [SC] disable mismatching tiles
                activePlayer.disableMismatchedTiles(tile.getColorIndex(), tile.getShapeIndex());

                // [SC] prevent the player from dropping tiles in the same turn
                activePlayer.setCanDrop(false);

                // [SC] reset board selection
                resetSelected();

                // [SC] update scores and tile buttons
                dropemWindow.updateControlPanel();
            }
        }

        protected override void createPlayers(string playerName, string[] aiID, bool giveHint) {
            players = new List<Player>();

            // [SC] creating a human player
            Player humanPlayer = new Player(0, Cfg.HUMAN_PLAYER, giveHint, this);
            humanPlayer.setPlayerName(playerName);
            this.humanPlayer = humanPlayer;
            fillPlayerTiles(humanPlayer);
            players.Add(humanPlayer);

            // [SC] creating AI players
            for (int currPlayerIndex = 0; currPlayerIndex < aiID.Length; currPlayerIndex++) {
                Player currPlayer = new Player(currPlayerIndex + 1, aiID[currPlayerIndex], false, this);
                fillPlayerTiles(currPlayer);
                players.Add(currPlayer);
            }
        }
    }
}
