﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.DropEm.SessionBased
Filename: DropEm.cs
Description:
    Extends and implements the class DropEmNet35.DropEm.DropEmGameWindow.
    The HAT-based adaptation uses an entire game session as a scenarios (AI difficulty adaptation is done after a game session).
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;

using System.Threading; // Thread
using System.ComponentModel; // CancelEventArgs

namespace DropEmNet35.DropEm.SessionBased
{
    public class DropEmGameWindow : DropEmNet35.DropEm.DropEmGameWindow
    {
        public const string GAME_ID = "DropEm";

        public DropEmGameWindow(MainWindow mainWindow)
            : base(mainWindow) {
        }

        protected override void initResources() {
            sw = new Stopwatch();

            visualBoard = new VisualBoard(this);
            ctrlPanel = new VisualControlPanel(this);

            myGame = new DropEmNet35.DropEm.SessionBased.Game(this, visualBoard);
        }

        public override void startNewGame(string adaptID, string playerID) {
            if (activeGameFlag) {
                Cfg.showMsg("Another game is already running.");
                return;
            }

            if (!initizliedFlag) {
                Cfg.showMsg("The game was not initialized.");
                return;
            }

            if (adaptID == null || playerID == null) {
                Cfg.showMsg("Null player or adaptation ID.");
                return;
            }

            string aiID = mainWindow.getTargetScenarioID(adaptID, GAME_ID, playerID);
            string[] aiIDArray;
            if (aiID == null) aiIDArray = new string[] { Cfg.MEDIUM_COLOR_AI }; // [SC] if no AI ID was provided then use default one
            else aiIDArray = new string[] { aiID };

            this.adaptID = adaptID;
            this.playerID = playerID;
            this.aiID = aiID;

            // [SC] check if stopwatch is running
            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            // [SC] initialize game logic
            myGame.initNewGame(playerID, aiIDArray, false, 30);

            // [SC] initialize visual board
            visualBoard.initBoard(myGame.getBoardRowCount(), myGame.getBoardColCount());
            visualBoard.resetBoard();

            // [SC] initialize control panel
            ctrlPanel.initPanel(Cfg.MAX_PLAYER_TILE_COUNT, 1 + aiIDArray.Length);
            updateControlPanel();

            workerThread = new Thread(myGame.startNewGame);
            workerThread.IsBackground = true;
            activeGameFlag = true;
            sw.Start();
            workerThread.Start();
        }

        // [SC] called by Game
        public override void endGame(double correctAnswer) {
            activeGameFlag = false;
            sw.Stop();
            double rt = sw.ElapsedMilliseconds;
            sw.Reset();

            mainWindow.updateRatings(adaptID, GAME_ID, playerID, aiID, rt, correctAnswer);

            if (workerThread != null) {
                if (workerThread.ThreadState == System.Threading.ThreadState.Running) {
                    myGame.forceEndGame();
                    workerThread.Join();
                }
                //while (workerThread.ThreadState != System.Threading.ThreadState.Stopped) ; // [SC]
            }
        }

        protected override void doClosingStuff(object sender, CancelEventArgs e) {
            if (workerThread != null) {
                if (workerThread.ThreadState == System.Threading.ThreadState.Running) {
                    myGame.forceEndGame();
                    workerThread.Join();
                }
                //while (workerThread.ThreadState != System.Threading.ThreadState.Stopped) ; // [SC]
            }

            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            mainWindow.Show();
        }
    }
}
