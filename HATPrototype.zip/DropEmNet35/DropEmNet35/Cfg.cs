﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35
Filename: Cfg.cs
Description:
    Contains configurational settings as constants, static variables and static utility methods for the DropEm game.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DropEmNet35 {
    public static class Cfg {

        public const string SELECT_DATAPATH_BTN_NAME = "selectDatapath";
        public const string NEW_PLAYER_BTN_NAME = "newPlayer";
        public const string START_GAME_BTN_NAME = "startGame";
        public const string VIS_WIDGET_BTN_NAME = "visWidget";

        public const int MAX_LABEL_WIDTH = 400;

        public const int BUTTON_WIDTH = 200;

        public const int PANEL_BOTTOM_MARGIN = 50;
        public const int PANEL_SIDE_MARGIN = 50;
        public const int LEFT_PANEL_WIDTH = 300;
        public const int RIGHT_PANEL_WIDTH = 300;

        public static void showMsg(string msg) {
            System.Windows.MessageBox.Show(msg);
        }
    }
}
