﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.Data
Filename: DataManager.cs
Description: 
    Data manager stores and retrieves player and scenario data from a data file in an XML format.
    This data manager is used by both the asset and the game.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Xml;
using System.Collections.ObjectModel; // ObservableCollection
using System.Diagnostics; // Debug
using System.Windows; // Point

namespace DropEmNet35.Data 
{
    public class DataManager 
    {
        private XmlDocument adaptXmlDoc;
        private XmlDocument logXmlDoc;

        private bool openDatastreamFlag;
        private string currDatapath;

        public DataManager() {
            openDatastreamFlag = false;
        }

        public bool openDatastream(string datapath) {
            try {
                adaptXmlDoc = new XmlDocument();
                adaptXmlDoc.Load(datapath + Cfg.ADAPT_DATA_FILENAME);

                logXmlDoc = new XmlDocument();
                logXmlDoc.Load(datapath + Cfg.LOG_DATA_FILENAME);

                currDatapath = datapath;

                openDatastreamFlag = true;

                return true;
            }
            catch (System.IO.FileNotFoundException) {
                return false;
            }
        }

        public void closeDatastream() {
            if (currDatapath != null && openDatastreamFlag) {
                adaptXmlDoc.Save(currDatapath + Cfg.ADAPT_DATA_FILENAME);
                logXmlDoc.Save(currDatapath + Cfg.LOG_DATA_FILENAME);

                currDatapath = null;

                openDatastreamFlag = false;
            }
        }

        public bool hasOpenDatasteam() {
            return openDatastreamFlag;
        }

        public XmlNode selectSingleNode(XmlNode xmlNode, string xPathString) {
            try {
                XmlNode newNode = xmlNode.SelectSingleNode(xPathString);
                return newNode;
            }
            catch (Exception) {
                return null;
            }
        }

        public XmlNodeList selectNodeList(XmlNode xmlNode, string xPathString) {
            try {
                XmlNodeList nodeList = xmlNode.SelectNodes(xPathString);
                return nodeList;
            }
            catch (Exception) {
                return null;
            }
        }

        //////////////////////////////////////////////////////////////////////////////
        ////// START: methods for the adaptXmlDoc

        public ObservableCollection<string> getAllAdaptations() {
            if (adaptXmlDoc == null) return null;

            XmlNodeList elemList = selectNodeList(adaptXmlDoc.DocumentElement, "Adaptation");

            if (elemList.Count == 0) return null;

            ObservableCollection<string> adaptIDList = new ObservableCollection<string>();

            for (int currIndex = 0; currIndex < elemList.Count; currIndex++) {
                XmlAttribute adaptID = (elemList[currIndex] as XmlElement).GetAttributeNode("AdaptationID");
                adaptIDList.Add(adaptID.InnerXml);
            }

            return adaptIDList;
        }

        public ObservableCollection<string> getAllGames(string adaptID) {
            if (adaptXmlDoc == null) return null;

            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']";
            XmlNode adaptNode = selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);

            if (adaptNode == null) return null;

            XmlNodeList elemList = selectNodeList(adaptNode, "Game");

            if (elemList.Count == 0) return null;

            ObservableCollection<string> gameIDList = new ObservableCollection<string>();

            for (int currIndex = 0; currIndex < elemList.Count; currIndex++) {
                XmlAttribute gameID = (elemList[currIndex] as XmlElement).GetAttributeNode("GameID");
                gameIDList.Add(gameID.InnerXml);
            }

            return gameIDList;
        }

        public ObservableCollection<string> getAllScenarios(string adaptID, string gameID) {
            if (adaptXmlDoc == null) return null;

            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']";
            XmlNode adaptNode = selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);

            if (adaptNode == null) return null;

            xPathString = "Game[@GameID='" + gameID + "']";
            XmlNode gameNode = selectSingleNode(adaptNode, xPathString);

            if (gameNode == null) return null;

            XmlNodeList elemList = selectNodeList(gameNode, "ScenarioData/Scenario");

            if (elemList.Count == 0) return null;

            ObservableCollection<string> scenarioIDList = new ObservableCollection<string>();

            for (int currIndex = 0; currIndex < elemList.Count; currIndex++) {
                XmlAttribute scenarioID = (elemList[currIndex] as XmlElement).GetAttributeNode("ScenarioID");
                scenarioIDList.Add(scenarioID.InnerXml);
            }

            return scenarioIDList;
        }

        public ObservableCollection<string> getAllPlayers(string adaptID, string gameID) {
            if (adaptXmlDoc == null) return null;

            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']";
            XmlNode adaptNode = selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);

            if (adaptNode == null) return null;

            xPathString = "Game[@GameID='" + gameID + "']";
            XmlNode gameNode = selectSingleNode(adaptNode, xPathString);

            if (gameNode == null) return null;

            XmlNodeList elemList = selectNodeList(gameNode, "PlayerData/Player");

            if (elemList.Count == 0) return null;

            ObservableCollection<string> playerIDList = new ObservableCollection<string>();

            for (int currIndex = 0; currIndex < elemList.Count; currIndex++) {
                XmlAttribute playerID = (elemList[currIndex] as XmlElement).GetAttributeNode("PlayerID");
                playerIDList.Add(playerID.InnerXml);
            }

            return playerIDList;
        }

        public XmlNode getPlayerNode(string adaptID, string gameID, string playerID) {
            if (adaptXmlDoc == null) return null;
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']/PlayerData/Player[@PlayerID='" + playerID + "']";
            return selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);
        }

        public bool addPlayer(string adaptID, string gameID, string playerID, double rating, double playCount, double kFactor, double uncertainty, string date) {
            // [SC] check validity of player ID
            if (playerID == null) {
                Debug.WriteLine("The player id cannot be null.");
                return false;
            }

            // [SC] check if Xml document is loaded
            if (adaptXmlDoc == null) return false;

            // [SC] if null then cannot find player data node
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']/PlayerData";
            XmlNode playerDataNode = selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);
            if (playerDataNode == null) {
                Debug.WriteLine("Cannot find PlayerData node.");
                return false;
            }

            // [SC] if true then the player already exists
            XmlNode playerNode = getPlayerNode(adaptID, gameID, playerID);
            if (playerNode != null) {
                Debug.WriteLine("The player with id " + playerID + " already exists.");
                return false;
            }

            XmlElement playerElem = adaptXmlDoc.CreateElement("Player");

            XmlAttribute playerIDAttr = adaptXmlDoc.CreateAttribute("PlayerID");
            playerIDAttr.Value = playerID;
            playerElem.Attributes.Append(playerIDAttr);

            XmlElement userRatingElem = adaptXmlDoc.CreateElement("Rating");
            userRatingElem.InnerText = "" + rating;
            playerElem.AppendChild(userRatingElem);

            XmlElement playerPlayCountElem = adaptXmlDoc.CreateElement("PlayCount");
            playerPlayCountElem.InnerText = "" + playCount;
            playerElem.AppendChild(playerPlayCountElem);

            XmlElement playerKFctElem = adaptXmlDoc.CreateElement("KFactor");
            playerKFctElem.InnerText = "" + kFactor;
            playerElem.AppendChild(playerKFctElem);

            XmlElement playerUElem = adaptXmlDoc.CreateElement("Uncertainty");
            playerUElem.InnerText = "" + uncertainty;
            playerElem.AppendChild(playerUElem);

            XmlElement playerDateElem = adaptXmlDoc.CreateElement("LastPlayed");
            playerDateElem.InnerText = date;
            playerElem.AppendChild(playerDateElem);

            playerDataNode.AppendChild(playerElem);

            return true;
        }

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: player data getters
        public string getPlayerRating(string adaptID, string gameID, string playerID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, playerID, null, "Rating")).InnerText;
        }

        public string getPlayerPlayCount(string adaptID, string gameID, string playerID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, playerID, null, "PlayCount")).InnerText;
        }

        public string getPlayerKFct(string adaptID, string gameID, string playerID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, playerID, null, "KFactor")).InnerText;
        }

        public string getPlayerUncertainty(string adaptID, string gameID, string playerID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, playerID, null, "Uncertainty")).InnerText;
        }

        public string getPlayerLastPlayed(string adaptID, string gameID, string playerID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, playerID, null, "LastPlayed")).InnerText;
        }
        ////// END: player data getters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: scenario data getters
        public string getScenarioRating(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "Rating")).InnerText;
        }

        public string getScenarioPlayCount(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "PlayCount")).InnerText;
        }

        public string getScenarioKFct(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "KFactor")).InnerText;
        }

        public string getScenarioUncertainty(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "Uncertainty")).InnerText;
        }

        public string getScenarioLastPlayed(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "LastPlayed")).InnerText;
        }

        public string getScenarioTimeLimit(string adaptID, string gameID, string scenarioID) {
            return getInfoElem(getAdaptXPath(adaptID, gameID, null, scenarioID, "TimeLimit")).InnerText;
        }
        ////// END: scenario data getters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: player data setters
        public bool setPlayerRating(string adaptID, string gameID, string playerID, double newRating) {
            string xPathString = getAdaptXPath(adaptID, gameID, playerID, null, "Rating");
            XmlElement playerRatingElem = getInfoElem(xPathString);
            if (playerRatingElem == null) return false;
            playerRatingElem.InnerText = "" + newRating;
            return true;
        }

        public bool setPlayerPlayCount(string adaptID, string gameID, string playerID, double newPlayCount) {
            string xPathString = getAdaptXPath(adaptID, gameID, playerID, null, "PlayCount");
            XmlElement playerPlayCountElem = getInfoElem(xPathString);
            if (playerPlayCountElem == null) return false;
            playerPlayCountElem.InnerText = "" + newPlayCount;
            return true;
        }

        public bool setPlayerKFct(string adaptID, string gameID, string playerID, double newKFct) {
            string xPathString = getAdaptXPath(adaptID, gameID, playerID, null, "KFactor");
            XmlElement playerKFctElem = getInfoElem(xPathString);
            if (playerKFctElem == null) return false;
            playerKFctElem.InnerText = "" + newKFct;
            return true;
        }

        public bool setPlayerUncertainty(string adaptID, string gameID, string playerID, double newUncertianty) {
            string xPathString = getAdaptXPath(adaptID, gameID, playerID, null, "Uncertainty");
            XmlElement playerUElem = getInfoElem(xPathString);
            if (playerUElem == null) return false;
            playerUElem.InnerText = "" + newUncertianty;
            return true;
        }

        public bool setPlayerLastPlayed(string adaptID, string gameID, string playerID, string newLastPlayed) {
            string xPathString = getAdaptXPath(adaptID, gameID, playerID, null, "LastPlayed");
            XmlElement playerLastPlayedElem = getInfoElem(xPathString);
            if (playerLastPlayedElem == null) return false;
            playerLastPlayedElem.InnerText = "" + newLastPlayed;
            return true;
        }
        ////// END: player data setters
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        ////// START: scenario data setters
        public bool setScenarioRating(string adaptID, string gameID, string scenarioID, double newRating) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "Rating");
            XmlElement scenarioRatingElem = getInfoElem(xPathString);
            if (scenarioRatingElem == null) return false;
            scenarioRatingElem.InnerText = "" + newRating;
            return true;
        }

        public bool setScenarioPlayCount(string adaptID, string gameID, string scenarioID, double newPlayCount) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "PlayCount");
            XmlElement scenarioPlayCountElem = getInfoElem(xPathString);
            if (scenarioPlayCountElem == null) return false;
            scenarioPlayCountElem.InnerText = "" + newPlayCount;
            return true;
        }

        public bool setScenarioKFct(string adaptID, string gameID, string scenarioID, double newKFct) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "KFactor");
            XmlElement scenarioKFctElem = getInfoElem(xPathString);
            if (scenarioKFctElem == null) return false;
            scenarioKFctElem.InnerText = "" + newKFct;
            return true;
        }

        public bool setScenarioUncertainty(string adaptID, string gameID, string scenarioID, double newUncertianty) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "Uncertainty");
            XmlElement scenarioUElem = getInfoElem(xPathString);
            if (scenarioUElem == null) return false;
            scenarioUElem.InnerText = "" + newUncertianty;
            return true;
        }

        public bool setScenarioLastPlayed(string adaptID, string gameID, string scenarioID, string newLastPlayed) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "LastPlayed");
            XmlElement scenarioLastPlayedElem = getInfoElem(xPathString);
            if (scenarioLastPlayedElem == null) return false;
            scenarioLastPlayedElem.InnerText = "" + newLastPlayed;
            return true;
        }

        public bool setScenarioTimeLimit(string adaptID, string gameID, string scenarioID, double timeLimit) {
            string xPathString = getAdaptXPath(adaptID, gameID, null, scenarioID, "TimeLimit");
            XmlElement scenarioTimeLimitElem = getInfoElem(xPathString);
            if (scenarioTimeLimitElem == null) return false;
            scenarioTimeLimitElem.InnerText = "" + timeLimit;
            return true;
        }
        ////// END: scenario data setters
        ////////////////////////////////////////////////////////////////////////////////////

        private string getAdaptXPath(string adaptID, string gameID, string playerID, string scenarioID, string nodeName) {
            string xPathString = "";
            if (adaptID != null) xPathString += "Adaptation[@AdaptationID='" + adaptID + "']";

            if (gameID != null) xPathString += "/Game[@GameID='" + gameID + "']";

            if (playerID != null) xPathString += "/PlayerData/Player[@PlayerID='" + playerID + "']";
            else if (scenarioID != null) xPathString += "/ScenarioData/Scenario[@ScenarioID='" + scenarioID + "']";

            if (nodeName != null) xPathString += "/" + nodeName;

            return xPathString;
        }

        public XmlElement getInfoElem(string xPathString) {
            // [SC] check if Xml document is loaded
            if (adaptXmlDoc == null) return null;

            XmlNode playerInfoNode = selectSingleNode(adaptXmlDoc.DocumentElement, xPathString);

            if (playerInfoNode == null) return null;

            return (playerInfoNode as XmlElement);
        }

        ////// END: methods for the adaptXmlDoc
        //////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////////////
        ////// START: methods for the logXmlDoc

        public bool createNewRecord(string adaptID, string gameID, string playerID, string scenarioID
                                , double rt, double accuracy, double userRating, double scenarioRating, string timestamp) {
            // [SC] check validity of player ID
            if (playerID == null || gameID == null || playerID == null || scenarioID == null || timestamp == null) {
                Debug.WriteLine("Null value detected in log record.");
                return false;
            }

            // [SC] check if Xml document is loaded
            if (logXmlDoc == null) return false;

            // [SC] if null then cannot find player data node
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']";
            XmlNode gameNode = selectSingleNode(logXmlDoc.DocumentElement, xPathString);
            if (gameNode == null) {
                Debug.WriteLine("Cannot find Game node.");
                return false;
            }

            XmlElement gameplayElem = logXmlDoc.CreateElement("Gameplay");

            XmlAttribute playerIDAttr = logXmlDoc.CreateAttribute("PlayerID");
            playerIDAttr.Value = playerID;
            gameplayElem.Attributes.Append(playerIDAttr);

            XmlAttribute scenarioIDAttr = logXmlDoc.CreateAttribute("ScenarioID");
            scenarioIDAttr.Value = scenarioID;
            gameplayElem.Attributes.Append(scenarioIDAttr);

            XmlAttribute timestampAttr = logXmlDoc.CreateAttribute("Timestamp");
            timestampAttr.Value = timestamp;
            gameplayElem.Attributes.Append(timestampAttr);

            XmlElement rtElem = logXmlDoc.CreateElement("RT");
            rtElem.InnerText = "" + rt;
            gameplayElem.AppendChild(rtElem);

            XmlElement accuracyElem = logXmlDoc.CreateElement("Accuracy");
            accuracyElem.InnerText = "" + accuracy;
            gameplayElem.AppendChild(accuracyElem);

            XmlElement userRatingElem = logXmlDoc.CreateElement("PlayerRating");
            userRatingElem.InnerText = "" + userRating;
            gameplayElem.AppendChild(userRatingElem);

            XmlElement scenarioRatingElem = logXmlDoc.CreateElement("ScenarioRating");
            scenarioRatingElem.InnerText = "" + scenarioRating;
            gameplayElem.AppendChild(scenarioRatingElem);

            gameNode.AppendChild(gameplayElem);

            return true;
        }

        public List<Point> getPlayerRatingChanges(string adaptID, string gameID, string scenarioID, string playerID, bool chrono) {
            if (!chrono) return getRatingChanges(adaptID, gameID, scenarioID, playerID, "PlayerRating");
            else return getRatingChangesChronological(adaptID, gameID, scenarioID, playerID, "PlayerRating");
        }

        public List<Point> getScenarioRatingChanges(string adaptID, string gameID, string scenarioID, string playerID, bool chrono) {
            if (!chrono) return getRatingChanges(adaptID, gameID, scenarioID, playerID, "ScenarioRating");
            else return getRatingChangesChronological(adaptID, gameID, scenarioID, playerID, "ScenarioRating");
        }

        private List<Point> getRatingChanges(string adaptID, string gameID, string scenarioID, string playerID, string ratingType) {
            // [SC] check if Xml document is loaded
            if (logXmlDoc == null) return null;

            // [SC] if null then cannot find player data node
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']/Gameplay";
            if (!scenarioID.Equals(Cfg.ALL_KEYWORD) && !playerID.Equals(Cfg.ALL_KEYWORD))
                xPathString += "[@ScenarioID='" + scenarioID + "' and @PlayerID='" + playerID + "']";
            else if (!scenarioID.Equals(Cfg.ALL_KEYWORD))
                xPathString += "[@ScenarioID='" + scenarioID + "']";
            else if (!playerID.Equals(Cfg.ALL_KEYWORD))
                xPathString += "[@PlayerID='" + playerID + "']";
            xPathString += "/" + ratingType;

            XmlNodeList ratingNodeList = selectNodeList(logXmlDoc.DocumentElement, xPathString);

            if (ratingNodeList == null) return null;

            //double[] ratings = new double[ratingNodeList.Count];

            List<Point> ratings = new List<Point>();

            for (int currIndex = 0; currIndex < ratingNodeList.Count; currIndex++) {
                double rating;
                if (Double.TryParse(ratingNodeList[currIndex].InnerText, out rating)) {
                    ratings.Add(new Point() { X = currIndex + 1, Y = rating });
                }
            }

            return ratings;
        }

        private List<Point> getRatingChangesChronological(string adaptID, string gameID, string scenarioID, string playerID, string ratingType) {
            // [SC] check if Xml document is loaded
            if (logXmlDoc == null) return null;

            List<Point> ratings = new List<Point>();

            // [SC] if null then cannot find player data node
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']/Gameplay";

            if (!playerID.Equals(Cfg.ALL_KEYWORD)) xPathString += "[@PlayerID='" + playerID + "']";

            if (scenarioID.Equals(Cfg.ALL_KEYWORD)) {
                xPathString += "/" + ratingType;

                XmlNodeList ratingNodeList = selectNodeList(logXmlDoc.DocumentElement, xPathString);

                if (ratingNodeList == null) return null;

                for (int currIndex = 0; currIndex < ratingNodeList.Count; currIndex++) {
                    double rating;
                    if (Double.TryParse(ratingNodeList[currIndex].InnerText, out rating)) {
                        ratings.Add(new Point() { X = currIndex + 1, Y = rating });
                    }
                }
            }
            else {
                XmlNodeList ratingNodeList = selectNodeList(logXmlDoc.DocumentElement, xPathString);

                if (ratingNodeList == null) return null;

                for (int currIndex = 0; currIndex < ratingNodeList.Count; currIndex++) {
                    XmlNode gameplayNode = ratingNodeList[currIndex];

                    if (gameplayNode.Attributes["ScenarioID"].Value.Equals(scenarioID)) {
                        double rating;
                        if (Double.TryParse(gameplayNode[ratingType].InnerText, out rating)) {
                            ratings.Add(new Point() { X = currIndex + 1, Y = rating });
                        }
                    }
                }
            }

            return ratings;
        }

        /*private List<Point> getRatingChangesChronological(string adaptID, string gameID, string scenarioID, string playerID, string ratingType) {
            // [SC] check if Xml document is loaded
            if (logXmlDoc == null) return null;

            // [SC] if null then cannot find player data node
            string xPathString = "Adaptation[@AdaptationID='" + adaptID + "']/Game[@GameID='" + gameID + "']/Gameplay";

            string targetAttr;
            string targetAttrVal;
            if (ratingType.Equals("PlayerRating")) {
                if (!scenarioID.Equals(Cfg.ALL_KEYWORD)) xPathString += "[@ScenarioID='" + scenarioID + "']";
                targetAttr = "PlayerID";
                targetAttrVal = playerID;
            }
            else {
                if (!playerID.Equals(Cfg.ALL_KEYWORD)) xPathString += "[@PlayerID='" + playerID + "']";
                targetAttr = "ScenarioID";
                targetAttrVal = scenarioID;
            }

            XmlNodeList gameplayNodeList = selectNodeList(logXmlDoc.DocumentElement, xPathString);

            if (gameplayNodeList == null) return null;

            List<Point> ratings = new List<Point>();

            for (int currIndex = 0; currIndex < gameplayNodeList.Count; currIndex++) {
                XmlNode gameplayNode = gameplayNodeList[currIndex];

                if (gameplayNode.Attributes[targetAttr].Value.Equals(targetAttrVal)) {
                    double rating;
                    if (Double.TryParse(gameplayNode[ratingType].InnerText, out rating)) {
                        ratings.Add(new Point() { X = currIndex + 1, Y = rating});
                    }
                }
            }

            return ratings;
        }*/

        ////// END: methods for the logXmlDoc
        //////////////////////////////////////////////////////////////////////////////
    }
}
