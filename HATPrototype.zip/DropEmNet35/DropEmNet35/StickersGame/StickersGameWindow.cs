﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.StickersGame
Filename: StickersGameWindow.cs
Description:
    UI component. Implements the main visual window for the Stickers game's view component.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows; // Window
using System.Threading; // Thread
using System.Windows.Threading; // Dispatcher
using System.ComponentModel; // CancelEventArgs
using System.Diagnostics; // Stopwatch
using System.Collections.ObjectModel; // ObservableCollection
using System.Windows.Controls; // DockPanel, Border

namespace DropEmNet35.StickersGame {
    public partial class StickersGameWindow : Window 
    {
        private MainWindow mainWindow;

        private Game myGame;
        private Stopwatch sw;
        private Thread workerThread;

        private BackgroundWorker worker;

        private BoardPanel boardPanel;
        private PlayerPanel humanPlayerPanel;
        private PlayerPanel aiPlayerPanel;

        private TextBox scoreBox;
        private ComboBox choiceCBox;
        private Button confirmBtn;
        private Button newGameBtn;

        private bool initizliedFlag = false;

        private string adaptID;
        private string playerID;
        private string aiID;

        private int humanPlayerChoice;

        public StickersGameWindow(MainWindow mainWindow) {
            this.mainWindow = mainWindow;

            Title = "Stickers";

            init();

            Show();
        }

        private void init() {
            initResources();
            initUI();
            Closing += doClosingStuff;

            initizliedFlag = true;
        }

        private void initResources() {
            sw = new Stopwatch();

            myGame = new Game(this);

            worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.WorkerSupportsCancellation = true;
        }

        private void initUI() {
            DockPanel mainDockPanel = new DockPanel();
            mainDockPanel.LastChildFill = true;

            /////////////////////////////////////////////////////////////////

            Border leftBorder = new Border();
            DockPanel.SetDock(leftBorder, Dock.Left);

            StackPanel leftStackPanel = new StackPanel();
            leftStackPanel.Orientation = Orientation.Vertical;
            //leftStackPanel.Width = Cfg.LEFT_PANEL_WIDTH;
            //leftStackPanel.Margin = new Thickness { Right = Cfg.PANEL_SIDE_MARGIN, Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            humanPlayerPanel = new PlayerPanel(this);
            boardPanel = new BoardPanel(this);
            aiPlayerPanel = new PlayerPanel(this);

            leftStackPanel.Children.Add(aiPlayerPanel);
            leftStackPanel.Children.Add(boardPanel);
            leftStackPanel.Children.Add(humanPlayerPanel);

            mainDockPanel.Children.Add(leftBorder);

            /////////////////////////////////////////////////////////////////

            Border rightBorder = new Border();
            DockPanel.SetDock(rightBorder, Dock.Right);

            StackPanel rightStackPanel = new StackPanel();
            rightStackPanel.Orientation = Orientation.Vertical;
            //rightStackPanel.Width = Cfg.RIGHT_PANEL_WIDTH;
            //rightStackPanel.Margin = new Thickness { Bottom = Cfg.PANEL_BOTTOM_MARGIN };

            ScrollViewer myScrollViewer = new ScrollViewer();
            myScrollViewer.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            myScrollViewer.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            //myScrollViewer.CanContentScroll = true;

            scoreBox = new TextBox();
            scoreBox.TextWrapping = TextWrapping.Wrap;
            scoreBox.AcceptsReturn = true;
            scoreBox.IsReadOnly = true;
            myScrollViewer.Height = Cfg.SCORE_BOX_HEIGHT;
            scoreBox.Width = Cfg.SCORE_BOX_WIDTH;

            myScrollViewer.Content = scoreBox;

            rightStackPanel.Children.Add(myScrollViewer);

            Label choiceLabel = new Label { Content = "Make your choice: " };

            choiceCBox = new ComboBox();
            choiceCBox.IsEnabled = false;

            confirmBtn = new Button();
            confirmBtn.Name = Cfg.CONFIRM_BTN_NAME;
            confirmBtn.Content = "Confirm";
            confirmBtn.Click += new RoutedEventHandler(confirmBtnClick);
            confirmBtn.HorizontalAlignment = HorizontalAlignment.Center;
            confirmBtn.IsEnabled = false;

            newGameBtn = new Button();
            newGameBtn.Name = Cfg.NEW_GAME_BTN_NAME;
            newGameBtn.Content = "Start New Game";
            newGameBtn.Click += new RoutedEventHandler(newGameBtnClick);
            newGameBtn.HorizontalAlignment = HorizontalAlignment.Center;
            newGameBtn.IsEnabled = true;

            rightStackPanel.Children.Add(choiceLabel);
            rightStackPanel.Children.Add(choiceCBox);
            rightStackPanel.Children.Add(confirmBtn);
            rightStackPanel.Children.Add(newGameBtn);

            rightBorder.Child = rightStackPanel;

            leftBorder.Child = leftStackPanel;

            mainDockPanel.Children.Add(rightBorder);

            /////////////////////////////////////////////////////////////////

            this.Content = mainDockPanel;

            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        public void startNewGame(string adaptID, string playerID) {
            if (myGame.isActiveGame()) {
                Cfg.showMsg("Another game is already running.");
                return;
            }

            if (!initizliedFlag) {
                Cfg.showMsg("The game was not initialized.");
                return;
            }

            if (adaptID == null || playerID == null) {
                Cfg.showMsg("Null player or adaptation ID.");
                return;
            }

            // [SC] check if stopwatch is running
            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            string aiPlayerID = mainWindow.getTargetScenarioID(adaptID, Cfg.GAME_ID, playerID);

            this.adaptID = adaptID;
            this.playerID = playerID;
            this.aiID = aiPlayerID;

            boardPanel.initPanel(myGame.getPlayerSticks());
            aiPlayerPanel.initPanel(aiPlayerID, false, myGame.getPlayerSticks());
            humanPlayerPanel.initPanel(playerID, true, myGame.getPlayerSticks());

            aiPlayerPanel.setPlayerMsg(aiPlayerID + " says: " + Cfg.getAIMessage(aiPlayerID));
            humanPlayerPanel.setPlayerMsg("" + playerID);

            newGameBtn.IsEnabled = false;

            myGame.initNewGame(playerID, aiPlayerID);

            Cfg.showMsg("You are playing with the " + aiPlayerID + ".");

            workerThread = new Thread(myGame.startNewGame);
            workerThread.IsBackground = true;
            sw.Start();
            workerThread.Start();
            scoreBox.Text = myGame.getGoalText();
        }

        public void startRoundNotification(int roundID, int playerStickers) {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                humanPlayerPanel.addCoins(playerStickers);
                aiPlayerPanel.addCoins(playerStickers);

                ObservableCollection<string> stickersList = new ObservableCollection<string>();
                for (int currStickers = 1; currStickers <= playerStickers; currStickers++) {
                    stickersList.Add("" + currStickers);
                }

                choiceCBox.SelectedIndex = -1;
                choiceCBox.ItemsSource = stickersList;
                choiceCBox.IsEnabled = true;

                confirmBtn.IsEnabled = true;

                Cfg.showMsg("Starting round " + roundID);
            }));
        }

        public void endRoundNotification(int roundID, string infoText) {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                //Cfg.showMsg("Ending round " + roundID);
                scoreBox.Text = infoText;
                boardPanel.clearCoins();

                // [SC] end of the game
                if (!myGame.isActiveGame()) {
                    sw.Stop();
                    double rt = sw.ElapsedMilliseconds;
                    sw.Reset();

                    mainWindow.updateRatings(adaptID, Cfg.GAME_ID, playerID, aiID, rt, myGame.getSuccess());

                    newGameBtn.IsEnabled = true;
                }
            }));
        }

        // [SC] event handler for confirmBtn button
        private void confirmBtnClick(object sender, RoutedEventArgs e) {
            if (choiceCBox.SelectedItem == null) {
                Cfg.showMsg("Make your choice.");
                return;
            }

            if (!Int32.TryParse(choiceCBox.SelectedItem as String, out humanPlayerChoice)) {
                return;
            }

            confirmBtn.IsEnabled = false;

            worker.RunWorkerAsync();
        }

        // [SC] event handler for the newGameBtn button
        private void newGameBtnClick(object sender, RoutedEventArgs e) {
            startNewGame(adaptID, playerID);
        }

        private void worker_DoWork(object sender, DoWorkEventArgs e) {
            for (int currCoinIndex = 0; currCoinIndex < humanPlayerChoice; currCoinIndex++) {
                if (worker.CancellationPending) break;

                moveHumanPlayerCoin();
                Thread.Sleep(100);
            }

            int aiChoice = myGame.getAiChoice();

            for (int currCoinIndex = 0; currCoinIndex < aiChoice; currCoinIndex++) {
                if (worker.CancellationPending) break;

                moveAIPlayerCoin();
                Thread.Sleep(100);
            }

            myGame.setHumanPlayerChoice(humanPlayerChoice);

            humanPlayerChoice = Cfg.NONE;

            e.Cancel = true;
        }

        private void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            // [SC] update ui once worker complete his work
        }

        public void moveHumanPlayerCoin() {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                Image coinImage = humanPlayerPanel.removeCoin();
                boardPanel.addHumanCoin(coinImage);
            }));
        }

        public void moveAIPlayerCoin() {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                Image coinImage = aiPlayerPanel.removeCoin();
                boardPanel.addAICoin(coinImage);
            }));
        }

        private void doClosingStuff(object sender, CancelEventArgs e) {
            if (workerThread != null) {
                if (workerThread.ThreadState == System.Threading.ThreadState.Running) {
                    myGame.forceEndGame();
                    workerThread.Join();
                }
                //while (workerThread.ThreadState != System.Threading.ThreadState.Stopped) ; // [SC]
            }

            if (worker.IsBusy) worker.CancelAsync();

            if (sw.IsRunning) {
                sw.Stop();
                sw.Reset();
            }

            mainWindow.Show();
        }
    }
}
