﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.StickersGame
Filename: Decision.cs
Description:
    A data structure representing player's choice with resulting score.
Disclaimer:
    This game is an adaptation of the Stickers game described in 
    "Sher, I., Koenig, M., & Rustichini, A. (2014). Children’s strategic theory of mind. 
    Proceedings of the National Academy of Sciences, 111(37), 13307-13312".
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DropEmNet35.StickersGame 
{
    public class Decision 
    {
        private int choice;
        private int score;

        public Decision(int choice, int score) {
            this.choice = choice;
            this.score = score;
        }

        public int getChoice() {
            return choice;
        }

        public int getScore() {
            return score;
        }
    }
}
