﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.Asset
Filename: GraphPanel.cs
Description: Provides a canvas and functions for graph drawing for the asset's visualization widget.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics; // Debug
using System.Windows.Controls; // Canvas
using System.Windows.Shapes; // Polyline
using System.Windows.Media; // PointCollection
using System.Windows; // Point

namespace DropEmNet35.Asset 
{
    public class GraphPanel : Canvas 
    {
        //private WidgetWindow widgetWindow;

        public GraphPanel()
            : base() {
            //this.Background = new SolidColorBrush(Cfg.CANVAS_BG);
            this.Width = Cfg.CANVAS_WIDTH;
            this.Height = Cfg.CANVAS_HEIGHT;
            //this.widgetWindow = widgetWindow;
        }

        public void drawGraph(double[] rawPoints) {
            List<Point> rawPointsList = new List<Point>();

            for (int currIndex = 0; currIndex < rawPoints.Length; currIndex++) {
                Point point = new Point();
                point.X = currIndex + 1;
                point.Y = rawPoints[currIndex];
                rawPointsList.Add(point);
            }

            drawGraph(rawPointsList);
        }

        public void drawGraph(List<Point> rawPoints) {
            clearCanvas();

            Point[] minMaxPoints = getRange(rawPoints);

            // [TODO]
            if (minMaxPoints == null) {
                Debug.WriteLine("Null points provided. Cannot draw a graph.");
                return;
            }

            drawGraph(rawPoints, minMaxPoints[0], minMaxPoints[1]);
        }

        public void drawGraph(List<Point> rawPoints, Point minRawPoint, Point maxRawPoint) {
            clearCanvas();

            // [TODO]
            if (minRawPoint == null || maxRawPoint == null) {
                Debug.WriteLine("Unknown range. Cannot draw a graph.");
                return;
            }

            int xRes = getXresolution(minRawPoint, maxRawPoint);
            int yRes = getYresolution(minRawPoint, maxRawPoint);

            PointCollection pixelPointCollection = getPixelPoints(rawPoints, xRes, yRes, minRawPoint);

            int breakPointCountX = 10; // [TODO]
            double rangeX = maxRawPoint.X - minRawPoint.X;
            if (rangeX % 2 != 0) rangeX++;
            if (rangeX < breakPointCountX) breakPointCountX = (int)rangeX;
            while (rangeX % breakPointCountX != 0) breakPointCountX++;

            drawAxes(xRes, yRes, minRawPoint, maxRawPoint, breakPointCountX, 10); // [TODO]
            drawLine(pixelPointCollection);
            drawScatter(pixelPointCollection);
        }

        // [TODO]
        private void drawAxes(int xRes, int yRes, Point minRawPoint, Point maxRawPoint, int breakPointCountX, int breakPointCountY) {
            Point startPointX = new Point();
            Point endPointX = new Point();

            startPointX.X = getStartPixelX();
            startPointX.Y = getEndPixelY() + Cfg.AXIS_OFFSET;
            endPointX.X = getEndPixelX();
            endPointX.Y = getEndPixelY() + Cfg.AXIS_OFFSET;

            Point startPointY = new Point();
            Point endPointY = new Point();

            startPointY.Y = getStartPixelY();
            startPointY.X = getStartPixelX() - Cfg.AXIS_OFFSET;
            endPointY.Y = getEndPixelY();
            endPointY.X = getStartPixelX() - Cfg.AXIS_OFFSET;

            drawLine(startPointX, endPointX);
            drawLine(startPointY, endPointY);

            double rangeX = maxRawPoint.X - minRawPoint.X;
            if (rangeX % 2 != 0) rangeX++;
            double breakLengthX = rangeX / breakPointCountX;

            double rangeY = maxRawPoint.Y - minRawPoint.Y;
            double breakLengthY = rangeY / breakPointCountY;

            // [TODO]
            double rawX = minRawPoint.X;
            double rawY = minRawPoint.Y;

            // [SC] drawing tick labels for X axis
            for (int currBreakIndex = 0; currBreakIndex < breakPointCountX; currBreakIndex++) {
                double currBreakX = Math.Round(minRawPoint.X + (currBreakIndex * breakLengthX), 3);
                Point pixelPoint = getPixelPoint(currBreakX, rawY, xRes, yRes, minRawPoint);
                addText(pixelPoint.X, pixelPoint.Y + Cfg.AXIS_OFFSET, "" + currBreakX);
            }

            // [SC] drawing tick labels for Y axis
            for (int currBreakIndex = 0; currBreakIndex < breakPointCountY; currBreakIndex++) {
                double currBreakY = Math.Round(minRawPoint.Y + (currBreakIndex * breakLengthY), 3);
                Point pixelPoint = getPixelPoint(rawX, currBreakY, xRes, yRes, minRawPoint);
                addText(pixelPoint.X + Cfg.Y_AXIS_TICK_MARGIN - Cfg.AXIS_OFFSET, pixelPoint.Y, "" + currBreakY);
                //addText(pixelPoint.X - Cfg.Y_AXIS_TICK_MARGIN - Cfg.AXIS_OFFSET, pixelPoint.Y, "" + currBreakY);
            }

            // [SC] drawing X axis label
            Point lablePixelPoint = getPixelPoint((maxRawPoint.X + minRawPoint.X) / 2, rawY, xRes, yRes, minRawPoint);
            addText(lablePixelPoint.X, lablePixelPoint.Y + Cfg.AXIS_OFFSET - Cfg.X_AXIS_LABEL_MARGIN, "Playthroughs");

            // [SC] drawing Y axis label
            TextBlock textBlock = new TextBlock();
            textBlock.Text = "Rating";
            textBlock.Foreground = new SolidColorBrush(Cfg.TEXT_COLOR);
            textBlock.LayoutTransform = new RotateTransform(-90);
            lablePixelPoint = getPixelPoint(rawX, (maxRawPoint.Y + minRawPoint.Y) / 2, xRes, yRes, minRawPoint);
            addText(lablePixelPoint.X - Cfg.AXIS_OFFSET + Cfg.Y_AXIS_TICK_MARGIN + Cfg.Y_AXIS_LABEL_MARGIN, lablePixelPoint.Y, textBlock);
        }

        private Point getPixelPoint(double rawPointX, double rawPointY, int xRes, int yRes, Point minRawPoint) {
            Point pixelPoint = new Point();
            pixelPoint.X = getStartPixelX() + (int)((rawPointX - minRawPoint.X) * xRes);
            pixelPoint.Y = getEndPixelY() - (int)((rawPointY - minRawPoint.Y) * yRes);
            //pixelPoint.Y = getStartPixelY() + (int)(rawPoint.Y * yRes); // [TODO][DEBUG]
            return pixelPoint;
        }

        private PointCollection getPixelPoints(List<Point> rawPoints, int xRes, int yRes, Point minRawPoint) {
            PointCollection pixelPointCollection = new PointCollection();
            foreach (Point rawPoint in rawPoints) {
                pixelPointCollection.Add(getPixelPoint(rawPoint.X, rawPoint.Y, xRes, yRes, minRawPoint));
            }
            return pixelPointCollection;
        }

        private int getStartPixelX() {
            return 0 + Cfg.DRAW_AREA_MARGIN;
        }

        private int getStartPixelY() {
            return 0 + Cfg.DRAW_AREA_MARGIN;
        }

        private int getEndPixelX() {
            return getWidth() - Cfg.DRAW_AREA_MARGIN;
        }

        private int getEndPixelY() {
            return getHeight() - Cfg.DRAW_AREA_MARGIN;
        }

        // [SC] returns the number of horizontal pixels per raw point
        private int getXresolution(Point minPoint, Point maxPoint) {
            return (int)((getEndPixelX() - getStartPixelX()) / (maxPoint.X - minPoint.X));
        }

        // [SC] returns the number of vertical pixels per raw point
        private int getYresolution(Point minPoint, Point maxPoint) {
            return (int)((getEndPixelY() - getStartPixelY()) / (maxPoint.Y - minPoint.Y));
        }

        // [SC] get min and max values for X and Y axis
        private Point[] getRange(List<Point> rawPoints) {

            if (rawPoints.Count == 0 || rawPoints[0] == null) return null;

            Point minPoint = new Point();
            Point maxPoint = new Point();

            minPoint.X = rawPoints[0].X;
            minPoint.Y = rawPoints[0].Y;

            maxPoint.X = rawPoints[0].X;
            maxPoint.Y = rawPoints[0].Y;

            for (int currPIndex = 1; currPIndex < rawPoints.Count; currPIndex++) {
                if (rawPoints[currPIndex] == null) return null;

                if (rawPoints[currPIndex].X < minPoint.X) minPoint.X = rawPoints[currPIndex].X;
                else if (rawPoints[currPIndex].X > maxPoint.X) maxPoint.X = rawPoints[currPIndex].X;

                if (rawPoints[currPIndex].Y < minPoint.Y) minPoint.Y = rawPoints[currPIndex].Y;
                else if (rawPoints[currPIndex].Y > maxPoint.Y) maxPoint.Y = rawPoints[currPIndex].Y;
            }

            return new Point[] { minPoint, maxPoint };
        }

        private void drawScatter(PointCollection pointCollection) {
            foreach (Point point in pointCollection) {
                Ellipse ellipse = new Ellipse { Width = Cfg.PCH_WIDTH, Height = Cfg.PCH_WIDTH };
                ellipse.StrokeThickness = Cfg.LINE_WIDTH;
                ellipse.Stroke = new SolidColorBrush(Cfg.LINE_COLOR);
                Canvas.SetLeft(ellipse, point.X - (Cfg.PCH_WIDTH / 2));
                Canvas.SetTop(ellipse, point.Y - (Cfg.PCH_WIDTH / 2));
                this.Children.Add(ellipse);
            }
        }

        private void drawLine(Point startPoint, Point endPoint) {
            Line line = new Line();
            line.X1 = startPoint.X;
            line.Y1 = startPoint.Y;
            line.X2 = endPoint.X;
            line.Y2 = endPoint.Y;
            line.Stroke = new SolidColorBrush(Cfg.LINE_COLOR);
            line.StrokeThickness = Cfg.LINE_WIDTH;
            this.Children.Add(line);
        }

        // [SC] pointCollection points should be in pixels
        private void drawLine(PointCollection pointCollection) {
            Polyline line = new Polyline();
            line.Points = pointCollection;
            line.Stroke = new SolidColorBrush(Cfg.LINE_COLOR);
            line.StrokeThickness = Cfg.LINE_WIDTH;
            this.Children.Add(line);
        }

        private void addText(double x, double y, string text) {
            TextBlock textBlock = new TextBlock();
            textBlock.Text = text;
            textBlock.Foreground = new SolidColorBrush(Cfg.TEXT_COLOR);
            addText(x, y, textBlock);
        }

        private void addText(double x, double y, TextBlock textBlock) {
            Canvas.SetLeft(textBlock, x);
            Canvas.SetTop(textBlock, y);
            this.Children.Add(textBlock);
        }

        public int getWidth() {
            return (int)this.Width;
        }

        public int getHeight() {
            return (int)this.Height;
        }

        private void clearCanvas() {
            this.Children.Clear();
        }
    }
}
