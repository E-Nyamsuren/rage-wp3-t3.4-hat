﻿/* 
Copyright 2015 Enkhbold Nyamsuren (http://www.bcogs.net , http://www.bcogs.info/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Namespace: DropEmNet35.Asset
Filename: WidgetWindow.cs
Description: 
    Implements the main window for the asset's visualization widget.
    Visualizes player's or scenario's ratings as timeseries.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls; // DockPanel, Border, StackPanel
using System.Collections.ObjectModel; // ObservableCollection
using System.ComponentModel; // CancelEventArgs
using System.Windows; // Point

namespace DropEmNet35.Asset 
{
    class WidgetWindow : Window 
    {
        private HATControlPanel hatCP;
        private GraphPanel graphPanel;
        private MainWindow mainWindow;

        public WidgetWindow(MainWindow mainWindow) {
            this.mainWindow = mainWindow;

            Title = "Visualization Widget";

            init();

            Show();
        }

        private void init() {
            initResources();

            initUI();

            Closing += doClosingStuff;
        }

        private void initResources() {
            hatCP = new HATControlPanel(this);
            hatCP.initPanel();

            graphPanel = new GraphPanel();
        }

        private void initUI() {
            DockPanel mainDockPanel = new DockPanel();
            mainDockPanel.LastChildFill = true;

            /////////////////////////////////////////////////////////////////

            Border hatControlBorder = new Border();
            DockPanel.SetDock(hatControlBorder, Dock.Left);

            hatControlBorder.Child = hatCP;
            mainDockPanel.Children.Add(hatControlBorder);

            /////////////////////////////////////////////////////////////////

            Border graphBorder = new Border();
            DockPanel.SetDock(graphBorder, Dock.Right);

            graphBorder.Child = graphPanel;
            mainDockPanel.Children.Add(graphBorder);

            /////////////////////////////////////////////////////////////////

            this.Content = mainDockPanel;

            this.SizeToContent = SizeToContent.WidthAndHeight;
        }

        public ObservableCollection<string> getAllAdaptations() {
            return mainWindow.getAllAdaptations();
        }

        public ObservableCollection<string> getAllGames(string adaptID) {
            return mainWindow.getAllGames(adaptID);
        }

        public ObservableCollection<string> getAllScenarios(string adaptID, string gameID) {
            return mainWindow.getAllScenarios(adaptID, gameID);
        }

        public ObservableCollection<string> getAllPlayers(string adaptID, string gameID) {
            return mainWindow.getAllPlayers(adaptID, gameID);
        }

        public void drawPlayerRatings(string adaptID, string gameID, string scenarioID, string playerID) {
            List<Point> playerRatings = mainWindow.getPlayerRatingChanges(adaptID, gameID, scenarioID, playerID);
            graphPanel.drawGraph(playerRatings);
        }

        public void drawScenarioRatings(string adaptID, string gameID, string scenarioID, string playerID) {
            List<Point> scenarioRatings = mainWindow.getScenarioRatingChanges(adaptID, gameID, scenarioID, playerID);
            graphPanel.drawGraph(scenarioRatings);
        }

        private void doClosingStuff(object sender, CancelEventArgs e) {
            mainWindow.Show();
        }
    }
}
